/**
 * ════════════════════════════════════════════════════════════════
 *  GLOBAL MEDIA URL SANITIZATION
 *  ────────────────────────────────────────────────────────────────
 *  Every media URL is converted to a human-readable label before
 *  reaching any UI surface: notifications, chat previews, etc.
 *  Discord CDN URLs are NEVER displayed to the user.
 * ════════════════════════════════════════════════════════════════ */

/** Friendly labels for rendered media messages */
export function sanitizeMessagePreview(text: string | null | undefined): string {
  if (!text) return "No messages yet";

  // Nudge messages
  if (text.startsWith('[nudge]')) return '✨ Nudge';
  if (text.startsWith('[story_v1]')) return '✨ Nudge';

  // Image markers
  if (text.startsWith('[img]')) return '📷 Photo';

  // Video markers
  if (text.startsWith('[video]')) return '🎬 Video';
  if (text.startsWith('[vid]')) return '🎬 Video';

  // Voice markers
  if (text.startsWith('[voice]')) return '🎙️ Voice Message';
  if (text.startsWith('[audio]')) return '🎙️ Voice Message';

  // Raw Discord CDN URL detection (Layer 2 — catch any that slip through)
  if (/https?:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net|images-ext-\d+\.discordapp\.net|discord\.com|cdn\.discord\.com)\/[^\s<>"']+/i.test(text)) {
    if (/\.(mp4|webm|mov|mkv)(\?|$)/i.test(text)) return '🎬 Video';
    if (/\.(mp3|wav|ogg|webm|m4a)(\?|$)/i.test(text)) return '🎙️ Voice Message';
    return '📷 Photo';
  }

  // Raw media URL patterns (generic)
  if (/https?:\/\/[^\s<>"']+\.(jpg|jpeg|png|gif|webp|bmp|svg)(\?|$)/i.test(text)) return '📷 Photo';
  if (/https?:\/\/[^\s<>"']+\.(mp4|webm|mov|mkv|avi)(\?|$)/i.test(text)) return '🎬 Video';
  if (/https?:\/\/[^\s<>"']+\.(mp3|wav|ogg|m4a)(\?|$)/i.test(text)) return '🎙️ Voice Message';

  // Upload.me / picser URLs
  if (/https?:\/\/(?:cdn\.)?(?:uploadme|picser)\./i.test(text)) return '📷 Photo';

  // Return as-is for plain text messages
  return text;
}

/** Extract clean media label for notification display */
export function getMediaNotificationLabel(text: string): string {
  if (!text) return 'Message';

  if (text.startsWith('[nudge]')) return '✨ Nudge';
  if (text.startsWith('[img]')) return '📷 Photo';
  if (text.startsWith('[video]') || text.startsWith('[vid]')) return '🎬 Video';
  if (text.startsWith('[voice]') || text.startsWith('[audio]')) return '🎙️ Voice Message';

  // Raw Discord CDN
  if (/https?:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net|images-ext-\d+\.discordapp\.net|discord\.com|cdn\.discord\.com)\/[^\s<>"']+/i.test(text)) {
    if (/\.(mp4|webm|mov|mkv)(\?|$)/i.test(text)) return '🎬 Video';
    if (/\.(mp3|wav|ogg|webm|m4a)(\?|$)/i.test(text)) return '🎙️ Voice Message';
    return '📷 Photo';
  }

  // Sent by user — truncate for notification
  return text.length > 60 ? text.slice(0, 57) + '...' : text;
}

/** Check if a message contains any media that needs sanitizing */
export function isMediaMessage(text: string): boolean {
  if (!text) return false;
  return (
    text.startsWith('[img]') ||
    text.startsWith('[video]') ||
    text.startsWith('[vid]') ||
    text.startsWith('[voice]') ||
    text.startsWith('[audio]') ||
    text.startsWith('[nudge]') ||
    text.startsWith('[story_v1]') ||
    /https?:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net|images-ext-\d+\.discordapp\.net|discord\.com|cdn\.discord\.com)\//i.test(text)
  );
}
