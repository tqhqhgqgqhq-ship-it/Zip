import { motion, AnimatePresence } from "framer-motion";

export interface ActionItem {
  label: string;
  icon: React.ReactNode;
  destructive?: boolean;
  onClick: () => void;
}

export function ActionSheet({
  open,
  onClose,
  items,
  title,
}: {
  open: boolean;
  onClose: () => void;
  items: ActionItem[];
  title?: string;
}) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-[200] bg-black/60 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 300 }}
            className="fixed inset-x-0 bottom-0 z-[210] mx-auto max-w-[420px] rounded-t-[28px] px-4 pb-8 pt-2"
            style={{
              background: "var(--bg-sheet, linear-gradient(178deg, #1E1A14 0%, #14110D 40%, #0F0D0A 100%))",
              border: "1px solid rgba(255,244,210,0.1)",
              boxShadow: "0 -8px 40px rgba(0,0,0,0.5)",
            }}
          >
            <div className="mx-auto mb-5 h-1 w-10 rounded-full bg-white/15" />
            {title && (
              <p className="mb-4 text-center text-[13px] font-semibold" style={{ color: "var(--text-secondary, #C9BCA6)" }}>
                {title}
              </p>
            )}
            <div className="flex flex-col gap-1.5">
              {items.map((item, i) => (
                <button
                  key={i}
                  onClick={() => { item.onClick(); onClose(); }}
                  className="flex items-center gap-3 rounded-2xl px-4 py-3.5 transition-colors"
                  style={{
                    background: item.destructive ? "rgba(220,38,38,0.08)" : "var(--bg-input, rgba(255,244,210,0.05))",
                    color: item.destructive ? "#ef4444" : "var(--text-primary, #F4EBD9)",
                  }}
                >
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl" style={{
                    background: item.destructive ? "rgba(220,38,38,0.12)" : "rgba(255,255,255,0.05)",
                  }}>
                    {item.icon}
                  </span>
                  <span className="text-[14px] font-semibold">{item.label}</span>
                </button>
              ))}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
