import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const file = formData.get("file") as File | null;
    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    const filename = file.name || "media";

    // 1. Try Catbox.moe (unlimited direct file host)
    try {
      const catboxForm = new FormData();
      catboxForm.append("reqtype", "fileupload");
      catboxForm.append("fileToUpload", file, filename);
      const res = await fetch("https://catbox.moe/user/api.php", {
        method: "POST",
        body: catboxForm,
        signal: AbortSignal.timeout(15000),
      });
      if (res.ok) {
        const text = await res.text();
        if (text.startsWith("http")) {
          return NextResponse.json({ success: true, url: text.trim(), provider: "Catbox (Server)" });
        }
      }
    } catch (e) {
      console.warn("[media-upload-server] Catbox failed:", e);
    }

    // 2. Try 0x0.st (unlimited direct file host)
    try {
      const zForm = new FormData();
      zForm.append("file", file, filename);
      const res = await fetch("https://0x0.st", {
        method: "POST",
        body: zForm,
        signal: AbortSignal.timeout(15000),
      });
      if (res.ok) {
        const text = await res.text();
        if (text.startsWith("http")) {
          return NextResponse.json({ success: true, url: text.trim(), provider: "0x0.st (Server)" });
        }
      }
    } catch (e) {
      console.warn("[media-upload-server] 0x0.st failed:", e);
    }

    // 3. Try Pixeldrain
    try {
      const res = await fetch(`https://pixeldrain.com/api/file/${encodeURIComponent(filename)}`, {
        method: "PUT",
        body: file,
        signal: AbortSignal.timeout(25000),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.id) {
          return NextResponse.json({ success: true, url: `https://pixeldrain.com/api/file/${data.id}`, provider: "Pixeldrain (Server)" });
        }
      }
    } catch (e) {
      console.warn("[media-upload-server] Pixeldrain failed:", e);
    }

    // 4. Try Discord Serverless CDN
    try {
      const dForm = new FormData();
      dForm.append("file", file, filename);
      const res = await fetch("https://discord-storage-serverless.animemoe.us/", {
        method: "POST",
        body: dForm,
        signal: AbortSignal.timeout(15000),
      });
      if (res.ok) {
        const data = await res.json();
        const url = data.url || data.cdn_url || data.file_url || (typeof data === "string" && data.startsWith("http") ? data : "");
        if (url && typeof url === "string" && url.startsWith("http")) {
          return NextResponse.json({ success: true, url, provider: "DiscordCDN (Server)" });
        }
      }
    } catch (e) {
      console.warn("[media-upload-server] Discord Serverless failed:", e);
    }

    return NextResponse.json({ error: "All server media upload hosts failed" }, { status: 502 });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || String(err) }, { status: 500 });
  }
}
