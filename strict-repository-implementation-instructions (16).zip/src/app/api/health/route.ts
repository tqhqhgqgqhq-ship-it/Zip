export const dynamic = "force-dynamic";

/**
 * Health check endpoint.
 *
 * The application's data layer is Turso (libSQL) accessed directly from the
 * client, plus device-local storage and external file/media hosts. There is
 * no server-side Postgres/ORM dependency, so this endpoint simply confirms the
 * server process is up and serving requests.
 */
export async function GET() {
  return Response.json({ ok: true });
}
