import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const file = formData.get("file") as File | null;
    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    // 1. Get GoFile server
    const sResp = await fetch("https://api.gofile.io/servers", { signal: AbortSignal.timeout(10000) });
    if (!sResp.ok) {
      return NextResponse.json({ error: "Failed to fetch GoFile servers" }, { status: 502 });
    }
    const sData = await sResp.json();
    const server = sData.data?.servers?.[0]?.name || "upload";

    // 2. Upload file to GoFile
    const gofileForm = new FormData();
    gofileForm.append("file", file, file.name || "attachment");

    const uResp = await fetch(`https://${server}.gofile.io/contents/uploadfile`, {
      method: "POST",
      body: gofileForm,
      signal: AbortSignal.timeout(60000),
    });

    if (!uResp.ok) {
      return NextResponse.json({ error: `GoFile HTTP ${uResp.status}` }, { status: 502 });
    }
    const uData = await uResp.json();
    if (uData.status === "ok" && uData.data?.downloadPage) {
      return NextResponse.json({
        success: true,
        url: uData.data.downloadPage,
        id: uData.data.id,
        filename: uData.data.name || file.name,
      });
    }

    return NextResponse.json({ error: "Invalid response from GoFile", raw: uData }, { status: 502 });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || String(err) }, { status: 500 });
  }
}
