import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// ═══════════════════════════════════════════════════════════════
//  FIREBASE CONFIGURATION
//  Replace these placeholders with your real Firebase credentials
// ═══════════════════════════════════════════════════════════════

const firebaseConfig = {
  apiKey: "AIzaSyADpzxDduOe0esjAXBtQ1z0goNNH71ySt8",
  authDomain: "word-weaver-9usyc.firebaseapp.com",
  projectId: "word-weaver-9usyc",
  storageBucket: "word-weaver-9usyc.firebasestorage.app",
  messagingSenderId: "259377788064",
  appId: "1:259377788064:web:ddf54721523d2e4efb85c5"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export default app;
