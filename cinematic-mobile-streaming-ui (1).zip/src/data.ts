export interface Movie {
  id: number;
  title: string;
  subtitle?: string;
  poster: string;
  glow: string; // accent glow color
  bg: string; // ambient background tint
  year: string;
  rating: string;
  genre: string;
  duration: string;
}

const img = (id: number, h = 1400, w = 920) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=${h}&w=${w}`;

// HERO carousel movies
export const heroMovies: Movie[] = [
  {
    id: 24286060,
    title: "JOHN WICK",
    subtitle: "CHAPTER 4",
    poster: img(24286060),
    glow: "#ff7a18",
    bg: "#3a1d05",
    year: "2023",
    rating: "8.9",
    genre: "Action · Thriller",
    duration: "2h 49m",
  },
  {
    id: 8717531,
    title: "NEON HEIST",
    subtitle: "FINAL RUN",
    poster: img(8717531),
    glow: "#22d3ee",
    bg: "#062b33",
    year: "2024",
    rating: "8.2",
    genre: "Sci-Fi · Crime",
    duration: "2h 11m",
  },
  {
    id: 28792993,
    title: "CRIMSON",
    subtitle: "THE AWAKENING",
    poster: img(28792993),
    glow: "#f43f5e",
    bg: "#3a0712",
    year: "2025",
    rating: "7.8",
    genre: "Horror · Mystery",
    duration: "1h 58m",
  },
  {
    id: 30217124,
    title: "THE OPERATIVE",
    subtitle: "NO MERCY",
    poster: img(30217124),
    glow: "#a78bfa",
    bg: "#1a1530",
    year: "2024",
    rating: "8.5",
    genre: "Action · Spy",
    duration: "2h 24m",
  },
];

const make = (ids: number[]): Movie[] =>
  ids.map((id, i) => ({
    id: id * 1000 + i,
    title: "",
    poster: img(id, 900, 600),
    glow: "#ff7a18",
    bg: "#1a1206",
    year: "2024",
    rating: (7 + Math.random() * 2).toFixed(1),
    genre: "Drama",
    duration: "1h 50m",
  }));

export const trending = make([8271458, 8717531, 7319359, 28792993, 30217124, 7299480]);
export const topRated = make([7319477, 24286060, 7299454, 12838778, 29263907, 33639139]);
export const tvShows = make([7319359, 11592363, 8271458, 30217124, 7299480, 8717531]);
export const recommended = make([33639139, 7299454, 28792993, 24286060, 7319477, 12838778]);
export const upcoming = make([29263907, 30217124, 7319359, 8717531, 7299480, 8271458]);

export const continueWatching = [
  { ...trending[0], progress: 0.65, name: "Dark Glory" },
  { ...topRated[1], progress: 0.3, name: "John Wick 4" },
  { ...tvShows[3], progress: 0.85, name: "The Operative" },
  { ...recommended[2], progress: 0.12, name: "Crimson" },
];

export const categories = ["Action", "Horror", "Anime", "Sci-Fi", "Comedy", "Drama", "Thriller"];

export const movieNames = [
  "Dark Glory", "Arcane", "Peaky Blinders", "The Witcher", "Blade Runner",
  "Oppenheimer", "Dune", "The Batman", "Tenet", "Sicario",
  "Drive", "Joker", "Heat", "Collateral", "Nightcrawler",
];
