export interface ImdbSearchItem {
  id: string;
  title: string;
  year?: string;
  actors?: string;
  poster?: string;
  imdbUrl?: string;
  rank?: number;
}

export async function searchImdb(query: string): Promise<ImdbSearchItem[]> {
  const q = query.trim();
  if (q.length < 2) return [];
  const response = await fetch(`https://imdb.iamidiotareyoutoo.com/search?q=${encodeURIComponent(q)}`);
  if (!response.ok) throw new Error(`IMDb search failed (${response.status})`);
  const data = await response.json();
  if (!data?.ok || !Array.isArray(data.description)) return [];
  return data.description.map((item: any) => ({
    id: item["#IMDB_ID"] || `${item["#TITLE"]}-${item["#YEAR"]}`,
    title: item["#TITLE"] || "Untitled",
    year: item["#YEAR"] ? String(item["#YEAR"]) : undefined,
    actors: item["#ACTORS"] || "",
    poster: item["#IMG_POSTER"] || "",
    imdbUrl: item["#IMDB_URL"] || "",
    rank: item["#RANK"],
  })) as ImdbSearchItem[];
}