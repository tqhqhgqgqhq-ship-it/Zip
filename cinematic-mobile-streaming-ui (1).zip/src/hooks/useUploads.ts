import { useEffect, useState } from "react";
import { loadAllMoviesFromCloud } from "../cloudStorage";
import type { MovieEntry } from "../telegram";

// ─── Global in-memory movie store backed by Turso cloud ───
let globalMovies: MovieEntry[] = [];
let loaded = false;
const listeners = new Set<(movies: MovieEntry[]) => void>();

function emit() {
  for (const fn of listeners) fn([...globalMovies]);
}

// Load all movies from Turso cloud (called on app start)
export async function refreshMoviesFromCloud(): Promise<MovieEntry[]> {
  try {
    const movies = await loadAllMoviesFromCloud();
    globalMovies = movies;
    loaded = true;
    emit();
    return movies;
  } catch (err) {
    console.error("[useUploads] Cloud refresh failed:", err);
    return globalMovies;
  }
}

// Add a movie to the global store immediately (after upload)
export function addMovieToStore(movie: MovieEntry) {
  // Dedupe
  globalMovies = [movie, ...globalMovies.filter((m) => m.id !== movie.id)];
  emit();
}

// Remove a movie from the global store (after deletion)
export function removeMovieFromStore(movieId: string) {
  globalMovies = globalMovies.filter((m) => m.id !== movieId);
  emit();
}

export function getStoreMovies(): MovieEntry[] {
  return globalMovies;
}

export function notifyUploadChanged() {
  refreshMoviesFromCloud();
}

// React hook — subscribes to the global store
export function useUploads(): MovieEntry[] {
  const [movies, setMovies] = useState<MovieEntry[]>(globalMovies);

  useEffect(() => {
    const fn = (m: MovieEntry[]) => setMovies(m);
    listeners.add(fn);

    // If not loaded yet, trigger a load
    if (!loaded) {
      refreshMoviesFromCloud();
    } else {
      setMovies(globalMovies);
    }

    return () => {
      listeners.delete(fn);
    };
  }, []);

  return movies;
}
