import { useRef, useState, useCallback, useEffect } from "react";

// ═══════════════════════════════════════════════════════════════
//  LIQUID GLASS PHYSICS ENGINE
//  Velocity-aware deformation: stretch when slow, squash when fast,
//  intelligent unsqueeze when motion slows (before release).
// ═══════════════════════════════════════════════════════════════

export interface LiquidState {
  dragging: boolean;
  fraction: number;      // 0..1 current position
  velocity: number;      // px/ms signed
  squash: number;        // 0 = relaxed, 1 = fully squeezed (height compression)
  stretchX: number;      // horizontal stretch factor under velocity
  blur: number;          // motion blur amount px
  pointerX: number;      // raw pointer x within track
}

const RELAX = 0.18;        // how fast squash relaxes toward target each frame
const VEL_DECAY = 0.82;    // velocity smoothing
const MAX_SQUASH = 1;
const SQUASH_VEL = 2.2;    // px/ms that maps to full squash

export function useLiquidPhysics(onSeek: (fraction: number) => void) {
  const trackRef = useRef<HTMLDivElement>(null);
  const [state, setState] = useState<LiquidState>({
    dragging: false,
    fraction: 0,
    velocity: 0,
    squash: 0,
    stretchX: 1,
    blur: 0,
    pointerX: 0,
  });

  const rafRef = useRef<number>(0);
  const lastXRef = useRef(0);
  const lastTRef = useRef(0);
  const rawVelRef = useRef(0);          // instantaneous velocity
  const smoothVelRef = useRef(0);       // smoothed velocity
  const targetFracRef = useRef(0);      // where finger is
  const draggingRef = useRef(false);
  const externalFracRef = useRef(0);    // playback position when not dragging

  const fracFromX = useCallback((clientX: number) => {
    const el = trackRef.current;
    if (!el) return 0;
    const r = el.getBoundingClientRect();
    return Math.max(0, Math.min(1, (clientX - r.left) / r.width));
  }, []);

  // Animation loop — runs only while dragging
  const tick = useCallback(() => {
    if (!draggingRef.current) return;

    // Smooth velocity toward raw
    smoothVelRef.current = smoothVelRef.current * VEL_DECAY + rawVelRef.current * (1 - VEL_DECAY);
    // Decay raw velocity each frame (so it falls toward 0 when finger stops moving)
    rawVelRef.current *= 0.6;

    const speed = Math.abs(smoothVelRef.current);
    const targetSquash = Math.min(MAX_SQUASH, speed / SQUASH_VEL);

    setState((prev) => {
      // Intelligent unsqueeze: squash relaxes toward target.
      // When finger slows, speed drops -> targetSquash drops -> relaxes BEFORE release.
      const squash = prev.squash + (targetSquash - prev.squash) * RELAX * 2.2;
      const stretchX = 1 + Math.min(0.35, speed / SQUASH_VEL * 0.35);
      const blur = Math.min(6, speed * 1.6);
      const el = trackRef.current;
      const px = el ? targetFracRef.current * el.getBoundingClientRect().width : prev.pointerX;
      return {
        ...prev,
        fraction: targetFracRef.current,
        velocity: smoothVelRef.current,
        squash,
        stretchX,
        blur,
        pointerX: px,
      };
    });

    rafRef.current = requestAnimationFrame(tick);
  }, []);

  const start = useCallback((clientX: number) => {
    draggingRef.current = true;
    lastXRef.current = clientX;
    lastTRef.current = performance.now();
    rawVelRef.current = 0;
    smoothVelRef.current = 0;
    const f = fracFromX(clientX);
    targetFracRef.current = f;
    setState((p) => ({ ...p, dragging: true, fraction: f }));
    cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(tick);
  }, [fracFromX, tick]);

  const move = useCallback((clientX: number) => {
    if (!draggingRef.current) return;
    const now = performance.now();
    const dt = Math.max(1, now - lastTRef.current);
    const dx = clientX - lastXRef.current;
    rawVelRef.current = dx / dt; // px per ms
    lastXRef.current = clientX;
    lastTRef.current = now;
    targetFracRef.current = fracFromX(clientX);
  }, [fracFromX]);

  const end = useCallback(() => {
    if (!draggingRef.current) return;
    draggingRef.current = false;
    cancelAnimationFrame(rafRef.current);
    const f = targetFracRef.current;
    onSeek(f);
    // Smooth relax animation after release
    let s = 0;
    const relax = () => {
      s += 0.12;
      setState((prev) => {
        const k = 1 - Math.pow(1 - Math.min(1, s), 3);
        const squash = prev.squash * (1 - k);
        const stretchX = 1 + (prev.stretchX - 1) * (1 - k);
        const blur = prev.blur * (1 - k);
        if (s >= 1) {
          return { ...prev, dragging: false, squash: 0, stretchX: 1, blur: 0 };
        }
        return { ...prev, squash, stretchX, blur };
      });
      if (s < 1) requestAnimationFrame(relax);
    };
    requestAnimationFrame(relax);
  }, [onSeek]);

  // External position update (during playback, not dragging)
  const setExternalFraction = useCallback((f: number) => {
    externalFracRef.current = f;
    if (!draggingRef.current) {
      setState((p) => ({ ...p, fraction: f }));
    }
  }, []);

  useEffect(() => () => cancelAnimationFrame(rafRef.current), []);

  return { trackRef, state, start, move, end, setExternalFraction };
}
