import { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  XIcon, UploadIcon, CheckCircleIcon, FilmIcon, ReelsIcon,
} from "../icons";
import { fallbackPoster } from "../metadataBrain";
import { searchImdb, type ImdbSearchItem } from "../imdbApi";
import {
  uploadVideoToTelegram,
  createMovieEntry,
  formatBytes,
  type UploadProgress,
  type TelegramUploadResult,
} from "../telegram";
import { saveMovieToCloud } from "../cloudStorage";
import { addMovieToStore } from "../hooks/useUploads";

type Step = "select" | "details" | "uploading" | "success";

const genreOptions = [
  "Action", "Comedy", "Drama", "Horror", "Thriller", "Romance",
  "Sci-Fi", "Fantasy", "Anime", "Documentary", "K-Drama", "Bollywood",
  "Turkish", "Cartoon", "Web Series",
];

export default function UploadPortal({
  open,
  onClose,
  user,
}: {
  open: boolean;
  onClose: () => void;
  user?: any;
}) {
  const [closing, setClosing] = useState(false);
  const [step, setStep] = useState<Step>("select");
  const [mode, setMode] = useState<"movie" | "reel">("movie");
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [year, setYear] = useState(new Date().getFullYear().toString());
  const [desc, setDesc] = useState("");
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [contentType, setContentType] = useState<string>("movie");
  const [uploadProgress, setUploadProgress] = useState<UploadProgress | null>(null);
  const [imdbResults, setImdbResults] = useState<ImdbSearchItem[]>([]);
  const [imdbLoading, setImdbLoading] = useState(false);
  const [selectedImdb, setSelectedImdb] = useState<ImdbSearchItem | null>(null);
  const [reelThumbnail, setReelThumbnail] = useState<string | null>(null);
  const [uploadResult, setUploadResult] = useState<TelegramUploadResult | null>(null);
  const [errorMsg, setErrorMsg] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const resetAll = () => {
    setStep("select");
    setMode("movie");
    setFile(null);
    setTitle("");
    setYear(new Date().getFullYear().toString());
    setDesc("");
    setSelectedGenres([]);
    setContentType("movie");
    setImdbResults([]);
    setSelectedImdb(null);
    setReelThumbnail(null);
    setUploadProgress(null);
    setUploadResult(null);
    setErrorMsg("");
  };

  const handleClose = () => {
    setClosing(true);
    setTimeout(() => {
      setClosing(false);
      onClose();
      resetAll();
    }, 450);
  };

  const triggerConfetti = () => {
    const duration = 3 * 1000;
    const animationEnd = Date.now() + duration;
    // @ts-ignore
    const confetti = window.confetti;
    if (!confetti) return;

    const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;

    const interval: any = setInterval(function() {
      const timeLeft = animationEnd - Date.now();
      if (timeLeft <= 0) return clearInterval(interval);
      const particleCount = 50 * (timeLeft / duration);
      confetti({ particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } });
      confetti({ particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } });
    }, 250);
  };

  const handleScan = async () => {
    if (!title || title.length < 2) return;
    setImdbLoading(true);
    setImdbResults([]);
    try {
      const results = await searchImdb(title);
      setImdbResults(results.slice(0, 5));
    } catch {
      setImdbResults([]);
    } finally {
      setImdbLoading(false);
    }
  };

  const applyImdb = (item: ImdbSearchItem) => {
    setSelectedImdb(item);
    setTitle(item.title);
    if (item.year) setYear(item.year);
    if (item.actors) setDesc(`Starring ${item.actors}.`);
  };

  const handleFile = (f?: File) => {
    if (!f) return;
    if (mode === "reel") {
      const video = document.createElement("video");
      video.preload = "auto";
      video.muted = true;
      video.playsInline = true;
      video.onloadeddata = () => { video.currentTime = 0.1; };
      video.onseeked = () => {
        const canvas = document.createElement("canvas");
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const thumb = canvas.toDataURL("image/jpeg", 0.8);
          setReelThumbnail(thumb);
        }
        window.URL.revokeObjectURL(video.src);
        if (video.duration > 61) {
          setErrorMsg("Reels are limited to 60 seconds.");
          setStep("select");
        } else {
          setFile(f);
          const parsed = f.name.replace(/\.[^.]+$/, "").replace(/[._\-\[\](){}]/g, " ").replace(/\d{3,4}p/gi, "").replace(/\s+/g, " ").trim();
          setTitle(parsed);
          setStep("details");
        }
      };
      video.src = URL.createObjectURL(f);
    } else {
      setFile(f);
      const parsed = f.name.replace(/\.[^.]+$/, "").replace(/[._\-\[\](){}]/g, " ").replace(/\d{3,4}p/gi, "").replace(/\s+/g, " ").trim();
      setTitle(parsed);
      setStep("details");
    }
  };

  const startRealUpload = async () => {
    if (!file || !title.trim()) return;
    setStep("uploading");
    setErrorMsg("");
    const caption = `<b>${title}</b>\n${desc}\n🎬 Uploaded via Reelio Studio`;

    try {
      const poster = reelThumbnail || selectedImdb?.poster || fallbackPoster(title.trim(), selectedGenres, year);
      const meta = { title: title.trim(), overview: desc, poster, genres: selectedGenres, year, type: contentType as any };
      const result = await uploadVideoToTelegram(file, caption, (p) => setUploadProgress({ ...p }));
      setUploadResult(result);
      const movie = createMovieEntry(result, meta);
      if (mode === "reel") movie.isReel = true;
      await saveMovieToCloud(movie, user?.id || "anonymous");
      addMovieToStore(movie);
      triggerConfetti();
      setStep("success");
    } catch (err: any) {
      setErrorMsg(err?.message || "Upload failed.");
      setStep("select");
    }
  };

  if (!open && !closing) return null;

  return (
    <div className={`fixed inset-0 z-[150] overflow-hidden ${closing ? "animate-details-out" : "animate-details-in"}`}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-[60px]" onClick={handleClose} />
      
      <div className="absolute inset-x-0 bottom-0 top-12 flex items-center justify-center p-4">
        <motion.div 
          initial={{ y: "100%", opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: "100%", opacity: 0 }}
          transition={{ type: "spring", damping: 30, stiffness: 300 }}
          className="relative w-full max-w-4xl h-full rounded-[44px] border border-white/10 bg-[#0a0a0f]/80 backdrop-blur-3xl shadow-[0_40px_120px_rgba(0,0,0,1)] flex flex-col overflow-hidden"
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-8 py-6 border-b border-white/5">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 flex items-center justify-center rounded-2xl bg-white/5 border border-white/10">
                <FilmIcon className="h-5 w-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-black tracking-tight text-white">Reelio Studio</h2>
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500">Professional Upload System</p>
              </div>
            </div>
            <button onClick={handleClose} className="h-10 w-10 flex items-center justify-center rounded-full bg-white/5 hover:bg-white/10 transition-colors">
              <XIcon className="h-5 w-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto no-scrollbar">
            <AnimatePresence mode="wait">
              {step === "select" && (
                <motion.div key="select" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="p-8 space-y-8">
                  <div className="text-center">
                    <h3 className="text-3xl font-black text-white tracking-tight">Create your cinema</h3>
                    <p className="mt-2 text-zinc-500">Select your masterpiece to share with the community</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <ModeCard active={mode === "movie"} onClick={() => setMode("movie")} icon={<FilmIcon className="h-6 w-6" />} label="Cinema Mode" sub="Full-length movies" />
                    <ModeCard active={mode === "reel"} onClick={() => setMode("reel")} icon={<ReelsIcon className="h-6 w-6" />} label="Short Clips" sub="Max 60 seconds" />
                  </div>

                  <div 
                    className={`relative h-64 rounded-[40px] border-2 border-dashed transition-all duration-500 flex flex-col items-center justify-center group cursor-pointer ${dragOver ? 'border-white bg-white/10' : 'border-white/10 bg-white/[0.02] hover:bg-white/[0.04]'}`}
                    onDragOver={e => { e.preventDefault(); setDragOver(true); }}
                    onDragLeave={() => setDragOver(false)}
                    onDrop={e => { e.preventDefault(); setDragOver(false); handleFile(e.dataTransfer.files[0]); }}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <input ref={fileInputRef} type="file" accept="video/*" className="hidden" onChange={e => handleFile(e.target.files?.[0])} />
                    <div className="h-20 w-20 rounded-[32px] bg-white text-black flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform duration-500">
                      <UploadIcon className="h-8 w-8" />
                    </div>
                    <p className="mt-6 text-lg font-black text-white">Drop your film here</p>
                    <p className="mt-1 text-sm text-zinc-500">or click to browse library</p>
                  </div>
                </motion.div>
              )}

              {step === "details" && (
                <motion.div key="details" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="p-8 space-y-8">
                  <div className="flex gap-8">
                    <div className="w-64 shrink-0 space-y-4">
                      <div className="aspect-[2/3] rounded-[32px] overflow-hidden border border-white/10 shadow-2xl bg-zinc-900">
                        <img src={reelThumbnail || selectedImdb?.poster || fallbackPoster(title, selectedGenres, year)} className="w-full h-full object-cover" />
                      </div>
                      <div className="rounded-2xl bg-white/5 border border-white/5 p-4 text-center">
                        <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Metadata Confidence</p>
                        <p className="text-xl font-black text-white mt-1">{selectedImdb ? '98%' : '60%'}</p>
                      </div>
                    </div>

                    <div className="flex-1 space-y-6">
                      <div className="grid gap-4">
                        <label className="block space-y-2">
                          <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em] ml-2">Movie Title</span>
                          <div className="flex gap-2">
                            <input value={title} onChange={e => setTitle(e.target.value)} className="flex-1 bg-white/[0.04] border border-white/10 rounded-2xl px-5 py-4 text-sm font-bold text-white outline-none focus:border-white/20" placeholder="Title..." />
                            <button onClick={handleScan} disabled={imdbLoading} className="px-6 rounded-2xl bg-white text-black text-xs font-black active:scale-95 disabled:opacity-50">SCAN</button>
                          </div>
                        </label>

                        {/* IMDb Search Results */}
                        <AnimatePresence>
                          {imdbResults.length > 0 && (
                            <motion.div 
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: "auto", opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              className="overflow-hidden space-y-2"
                            >
                              <p className="text-[9px] font-bold text-zinc-600 uppercase tracking-widest ml-2">Search Matches</p>
                              {imdbResults.map(item => (
                                <button 
                                  key={item.id}
                                  onClick={() => applyImdb(item)}
                                  className={`w-full flex items-center gap-3 p-2 rounded-2xl border transition-all ${selectedImdb?.id === item.id ? 'bg-white/10 border-white/20' : 'bg-white/[0.02] border-white/5 hover:bg-white/5'}`}
                                >
                                  <img src={item.poster} className="h-10 w-7 rounded object-cover" />
                                  <div className="text-left min-w-0">
                                    <p className="text-xs font-bold text-white truncate">{item.title}</p>
                                    <p className="text-[10px] text-zinc-500">{item.year} · {item.actors?.split(',')[0]}</p>
                                  </div>
                                  {selectedImdb?.id === item.id && <CheckCircleIcon className="ml-auto h-4 w-4 text-emerald-400" />}
                                </button>
                              ))}
                            </motion.div>
                          )}
                        </AnimatePresence>

                        <div className="grid grid-cols-3 gap-4">
                          <label className="block space-y-2 col-span-1">
                            <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em] ml-2">Release Year</span>
                            <input value={year} onChange={e => setYear(e.target.value)} className="w-full bg-white/[0.04] border border-white/10 rounded-2xl px-5 py-4 text-sm font-bold text-white outline-none focus:border-white/20 text-center" />
                          </label>
                          <label className="block space-y-2 col-span-2">
                            <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em] ml-2">Content Type</span>
                            <div className="flex bg-white/[0.04] rounded-2xl p-1 border border-white/10">
                              {['movie', 'tv', 'anime'].map(t => (
                                <button key={t} onClick={() => setContentType(t)} className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${contentType === t ? 'bg-white text-black' : 'text-zinc-500'}`}>{t}</button>
                              ))}
                            </div>
                          </label>
                        </div>

                        <label className="block space-y-2">
                          <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em] ml-2">Story Synopsis</span>
                          <textarea value={desc} onChange={e => setDesc(e.target.value)} rows={3} className="w-full bg-white/[0.04] border border-white/10 rounded-2xl px-5 py-4 text-sm font-medium text-zinc-300 outline-none focus:border-white/20 resize-none" placeholder="What's this about?" />
                        </label>

                        <div className="space-y-2">
                          <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em] ml-2">Genres</span>
                          <div className="flex flex-wrap gap-1.5">
                            {genreOptions.slice(0, 8).map(g => (
                              <button
                                key={g}
                                onClick={() => setSelectedGenres(prev => prev.includes(g) ? prev.filter(x => x !== g) : [...prev, g].slice(0, 3))}
                                className={`px-3 py-1.5 rounded-full border text-[10px] font-bold transition-all ${selectedGenres.includes(g) ? 'bg-white text-black border-white' : 'bg-white/5 text-zinc-500 border-white/5 hover:border-white/10'}`}
                              >
                                {g}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      {errorMsg && (
                        <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-4 text-xs font-bold text-red-400 animate-shake">
                          {errorMsg}
                        </div>
                      )}

                      <div className="flex gap-3 pt-4">
                        <button onClick={() => setStep("select")} className="flex-1 py-4 rounded-2xl border border-white/10 bg-white/5 text-sm font-black text-white active:scale-95 transition-all">Cancel</button>
                        <button onClick={startRealUpload} className="flex-[2] py-4 rounded-2xl bg-white text-black text-sm font-black shadow-2xl shadow-white/20 active:scale-95 transition-all">PUBLISH CINEMA</button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {step === "uploading" && (
                <div className="flex-1 flex flex-col items-center justify-center p-12">
                   <div className="relative h-48 w-48 mb-12">
                     <svg className="absolute inset-0 h-full w-full" viewBox="0 0 100 100">
                       <circle cx="50" cy="50" r="48" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="2" />
                       <motion.circle cx="50" cy="50" r="48" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" 
                         strokeDasharray="301.59"
                         animate={{ strokeDashoffset: 301.59 - (301.59 * (uploadProgress?.percent || 0) / 100) }}
                         style={{ rotate: -90, originX: "50px", originY: "50px" }}
                       />
                     </svg>
                     <div className="absolute inset-0 flex flex-col items-center justify-center">
                       <span className="text-5xl font-black text-white">{Math.round(uploadProgress?.percent || 0)}%</span>
                       <span className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mt-2">Uploading</span>
                     </div>
                   </div>
                   <h3 className="text-2xl font-black text-white mb-2">{uploadProgress?.message || 'Processing...'}</h3>
                   <p className="text-zinc-500 text-sm">{formatBytes(uploadProgress?.bytesUploaded || 0)} / {formatBytes(uploadProgress?.bytesTotal || 0)}</p>
                </div>
              )}

              {step === "success" && (
                <div className="flex-1 flex flex-col items-center justify-center p-12 text-center">
                  <div className="h-28 w-28 rounded-[40px] bg-emerald-500 text-white flex items-center justify-center shadow-[0_20px_50px_rgba(16,185,129,0.4)] mb-8">
                    <CheckCircleIcon className="h-14 w-14" />
                  </div>
                  <h3 className="text-3xl font-black text-white mb-3 tracking-tight">Cinema Published!</h3>
                  <p className="text-zinc-400 max-w-[320px] text-sm leading-relaxed mb-6">Your content is now live in the Reelio community cloud. Confetti time! 🎉</p>
                  
                  {uploadResult && (
                    <div className="bg-white/5 border border-white/10 rounded-3xl p-4 w-full max-w-sm mb-10">
                      <div className="flex items-center gap-3">
                         <div className="flex-1 text-left">
                            <p className="text-xs font-black text-white uppercase tracking-widest">{title}</p>
                            <p className="text-[10px] text-zinc-500 font-bold mt-1 uppercase tracking-tighter">ID: {uploadResult.fileUniqueId.slice(0, 16)}</p>
                         </div>
                         <div className="text-right">
                            <p className="text-[10px] font-black text-emerald-400 uppercase">Live</p>
                            <p className="text-[10px] text-zinc-500">{formatBytes(uploadResult.fileSize)}</p>
                         </div>
                      </div>
                    </div>
                  )}

                  <button onClick={handleClose} className="btn-3d-play px-12 py-4 rounded-3xl text-lg font-black">Close Studio</button>
                </div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

function ModeCard({ active, onClick, icon, label, sub }: any) {
  return (
    <button onClick={onClick} className={`relative overflow-hidden group p-6 rounded-[32px] border transition-all duration-500 ${active ? 'border-white/20 bg-white/10 shadow-2xl scale-[1.02]' : 'border-white/5 bg-white/[0.02] opacity-60 hover:opacity-100'}`}>
      <div className={`relative z-10 flex flex-col items-center text-center ${active ? 'text-white' : 'text-zinc-400'}`}>
        <div className={`mb-3 flex h-12 w-12 items-center justify-center rounded-2xl ${active ? 'bg-white text-black' : 'bg-white/5'}`}>{icon}</div>
        <p className="text-sm font-black tracking-tight">{label}</p>
        <p className="mt-1 text-[10px] font-bold text-zinc-500 uppercase tracking-widest">{sub}</p>
      </div>
    </button>
  );
}
