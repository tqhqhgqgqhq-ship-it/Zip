import { useEffect, useRef, useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  XIcon, HeartIcon, MessageIcon, ShareIcon, 
  PlayIcon, UserIcon, CheckCircleIcon, StarIcon
} from "../icons";
import { useUploads } from "../hooks/useUploads";
import { getStreamUrl, type MovieEntry } from "../telegram";
import { toggleLike, hasLiked, addComment, getComments, type Comment } from "../cloudStorage";
import { getSession } from "../auth";

function CommentSheet({ 
  movieId, 
  onClose 
}: { 
  movieId: string; 
  onClose: () => void;
}) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState("");
  const [loading, setLoading] = useState(true);
  const session = getSession();

  useEffect(() => {
    getComments(movieId).then(data => {
      setComments(data);
      setLoading(false);
    });
  }, [movieId]);

  const handlePost = async () => {
    if (!newComment.trim() || !session) return;
    const text = newComment.trim();
    setNewComment("");
    await addComment(session.id, movieId, text);
    const updated = await getComments(movieId);
    setComments(updated);
  };

  return (
    <motion.div 
      initial={{ y: "100%" }}
      animate={{ y: 0 }}
      exit={{ y: "100%" }}
      transition={{ type: "spring", damping: 30, stiffness: 300 }}
      className="absolute inset-x-0 bottom-0 z-[110] h-[70%] rounded-t-[40px] border-t border-white/10 bg-[#0a0a0f]/90 backdrop-blur-[60px] shadow-2xl flex flex-col"
      onClick={(e) => e.stopPropagation()}
    >
      <div className="p-5 border-b border-white/5 flex items-center justify-between">
        <h3 className="text-lg font-black tracking-tight text-white">Discussion ({comments.length})</h3>
        <button onClick={onClose} className="h-10 w-10 flex items-center justify-center rounded-full bg-white/5">
          <XIcon className="h-5 w-5" />
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto p-5 space-y-6 no-scrollbar">
        {loading ? (
          <div className="flex h-40 items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-white/10 border-t-white" />
          </div>
        ) : comments.length === 0 ? (
          <div className="text-center py-12 text-zinc-500 text-sm italic font-medium">Be the first to share your thoughts on this masterpiece.</div>
        ) : (
          comments.map(c => (
            <div key={c.id} className="flex gap-4">
              <div className="h-10 w-10 shrink-0 rounded-full bg-zinc-800 border border-white/10 overflow-hidden shadow-xl">
                {c.avatarUrl ? <img src={c.avatarUrl} className="h-full w-full object-cover" /> : <UserIcon className="p-2 h-full w-full text-zinc-500" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-black text-white">{c.userName}</p>
                <p className="mt-1 text-sm text-zinc-300 leading-relaxed font-medium">{c.text}</p>
                <p className="mt-2 text-[9px] font-bold text-zinc-600 uppercase tracking-widest">{new Date(c.createdAt).toLocaleDateString()}</p>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="p-5 border-t border-white/5 pb-10">
        <div className="flex gap-3 bg-white/5 p-1.5 rounded-2xl border border-white/10">
          <input 
            value={newComment}
            onChange={e => setNewComment(e.target.value)}
            placeholder="Write a comment..."
            className="flex-1 bg-transparent px-4 py-3 text-sm text-white outline-none placeholder:text-zinc-600"
          />
          <button 
            onClick={handlePost}
            disabled={!newComment.trim()}
            className="h-11 w-11 flex items-center justify-center rounded-xl bg-white text-black active:scale-95 disabled:opacity-50 transition-all shadow-xl"
          >
            <PlayIcon className="h-4 w-4 ml-1 rotate-[-90deg]" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}

function ReelItem({ 
  movie, 
  isActive 
}: { 
  movie: MovieEntry; 
  isActive: boolean; 
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);
  const [streamUrl, setStreamUrl] = useState<string | null>(null);
  const [liked, setLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(movie.likes);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const session = getSession();

  useEffect(() => {
    let cancelled = false;
    if (isActive) {
      getStreamUrl(movie).then(url => {
        if (!cancelled) setStreamUrl(url);
      });
      if (session) {
        hasLiked(session.id, movie.id).then(setLiked);
      }
    }
    return () => { cancelled = true; };
  }, [movie, isActive, session]);

  useEffect(() => {
    if (isActive && streamUrl && videoRef.current) {
      videoRef.current.play().catch(() => {});
      setPlaying(true);
    } else if (videoRef.current) {
      videoRef.current.pause();
      setPlaying(false);
    }
  }, [isActive, streamUrl]);

  const handleToggleLike = async () => {
    if (!session) return;
    const isNowLiked = await toggleLike(session.id, movie.id);
    setLiked(isNowLiked);
    setLikesCount(prev => isNowLiked ? prev + 1 : Math.max(0, prev - 1));
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (playing) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    setPlaying(!playing);
  };

  return (
    <div className="relative h-full w-full snap-start overflow-hidden bg-black">
      {streamUrl ? (
        <video
          ref={videoRef}
          src={streamUrl}
          loop
          playsInline
          className="h-full w-full object-cover"
          onClick={togglePlay}
        />
      ) : (
        <div className="flex h-full w-full items-center justify-center bg-zinc-950">
          <div className="h-16 w-16 animate-spin rounded-full border-[3px] border-white/5 border-t-orange-500" />
        </div>
      )}

      {/* Interactions Overlay */}
      <div className="absolute right-4 bottom-32 z-20 flex flex-col gap-6">
        <div className="flex flex-col items-center gap-2">
          <motion.button 
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.8 }}
            onClick={handleToggleLike}
            className={`relative flex h-16 w-16 items-center justify-center rounded-full backdrop-blur-3xl border transition-all duration-500 ${liked ? 'bg-rose-500 border-rose-400 text-white shadow-[0_0_40px_rgba(244,63,94,0.4)]' : 'bg-black/20 border-white/10 text-white'}`}
          >
             <AnimatePresence>
              {liked && (
                <motion.div
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 2, opacity: 0 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 bg-rose-500 rounded-full"
                />
              )}
            </AnimatePresence>
            <HeartIcon className="h-8 w-8 relative z-10" style={{ fill: liked ? "currentColor" : "none" }} />
          </motion.button>
          <span className="text-xs font-black text-white drop-shadow-lg tabular-nums">{likesCount}</span>
        </div>

        <div className="flex flex-col items-center gap-2">
          <motion.button 
            whileTap={{ scale: 0.8 }}
            onClick={() => setCommentsOpen(true)}
            className="flex h-16 w-16 items-center justify-center rounded-full backdrop-blur-3xl bg-black/20 border border-white/10 shadow-2xl text-white"
          >
            <MessageIcon className="h-8 w-8" />
          </motion.button>
          <span className="text-xs font-black text-white drop-shadow-lg uppercase tracking-widest">Chat</span>
        </div>

        <div className="flex flex-col items-center gap-2">
          <motion.button 
            whileTap={{ scale: 0.8 }}
            className="flex h-16 w-16 items-center justify-center rounded-full backdrop-blur-3xl bg-black/20 border border-white/10 shadow-2xl text-white"
          >
            <ShareIcon className="h-8 w-8" />
          </motion.button>
          <span className="text-xs font-black text-white drop-shadow-lg uppercase tracking-widest">Send</span>
        </div>
      </div>

      {/* Info Overlay */}
      <div className="absolute left-0 right-24 bottom-0 z-10 bg-gradient-to-t from-black/95 via-black/20 to-transparent p-8 pb-32 text-white pointer-events-none">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 overflow-hidden rounded-2xl border-2 border-white/10 bg-zinc-800 shadow-2xl ring-4 ring-white/5">
            <UserIcon className="h-full w-full object-cover p-2.5 text-zinc-500" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <p className="text-base font-black tracking-tight text-white drop-shadow-lg">{movie.uploadedBy || "Creator"}</p>
              <CheckCircleIcon className="h-4 w-4 text-emerald-400" />
            </div>
            <p className="text-[10px] font-black uppercase tracking-[0.3em] text-orange-400 drop-shadow-md">Verified Cinema</p>
          </div>
        </div>
        <h3 className="mt-5 text-2xl font-black leading-tight tracking-tight drop-shadow-[0_4px_12px_rgba(0,0,0,1)] text-white">{movie.title}</h3>
        <p className="mt-2 line-clamp-2 text-sm font-medium text-zinc-300 drop-shadow-lg opacity-80 leading-relaxed max-w-[90%]">
          {movie.overview || "Experience this breathtaking cinematic moment shared by our community."}
        </p>
        <div className="mt-6 flex items-center gap-2.5">
          {movie.genres.slice(0, 2).map(g => (
            <span key={g} className="rounded-full bg-white/10 border border-white/10 px-4 py-1.5 text-[11px] font-black uppercase tracking-wider backdrop-blur-3xl text-zinc-200">
              {g}
            </span>
          ))}
          <div className="flex items-center gap-2 rounded-full bg-orange-500/20 border border-orange-500/40 px-4 py-1.5 text-[11px] font-black uppercase tracking-wider text-orange-300 backdrop-blur-3xl">
            <StarIcon className="h-3.5 w-3.5" />
            <span>TOP REEL</span>
          </div>
        </div>
      </div>

      {/* Interactions Sheets */}
      <AnimatePresence>
        {commentsOpen && (
          <CommentSheet movieId={movie.id} onClose={() => setCommentsOpen(false)} />
        )}
      </AnimatePresence>

      {/* Play/Pause Center Indicator */}
      <AnimatePresence>
        {!playing && (
          <motion.div 
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 1.5, opacity: 0 }}
            className="absolute inset-0 flex items-center justify-center pointer-events-none z-30"
          >
            <div className="flex h-28 w-28 items-center justify-center rounded-full bg-black/30 border border-white/10 backdrop-blur-[40px] shadow-2xl">
              <PlayIcon className="h-12 w-12 text-white ml-2" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Progress bar at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/10 z-20">
         <motion.div 
           initial={{ width: 0 }}
           animate={{ width: isActive ? "100%" : 0 }}
           transition={{ duration: 15, ease: "linear" }}
           className="h-full bg-gradient-to-r from-orange-500 to-amber-300 shadow-[0_0_12px_rgba(255,122,24,0.6)]" 
         />
      </div>
    </div>
  );
}

export default function ReelsFeed({ open, onClose }: { open: boolean; onClose: () => void }) {
  const uploads = useUploads();
  const reels = useMemo(() => uploads.filter(m => m.isReel), [uploads]);
  const [activeIndex, setActiveIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const el = containerRef.current;
    if (!el) return;

    const onScroll = () => {
      const index = Math.round(el.scrollTop / el.clientHeight);
      if (index !== activeIndex) setActiveIndex(index);
    };

    el.addEventListener("scroll", onScroll);
    return () => el.removeEventListener("scroll", onScroll);
  }, [open, activeIndex]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-black">
      {reels.length === 0 ? (
        <div className="flex h-full flex-col items-center justify-center p-12 text-center text-white">
          <div className="mb-10 relative">
            <div className="absolute inset-0 bg-orange-500/10 blur-[100px] rounded-full" />
            <div className="relative h-28 w-28 rounded-[40px] bg-zinc-900 flex items-center justify-center border border-white/10 shadow-2xl">
               <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent rounded-[40px]" />
              <svg width="48" height="50" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" className="text-zinc-700">
                <rect x="2" y="2" width="20" height="20" rx="2" />
                <path d="m15 2-3.5 10L8 2M2 12h20M2 7h20M7 12l5 5 5-5" />
              </svg>
            </div>
          </div>
          <h3 className="text-3xl font-black tracking-tight text-gradient-white">Reels are quiet</h3>
          <p className="mt-4 text-zinc-500 max-w-[280px] leading-relaxed font-medium">Join our cinema community and share your first 60s cinematic masterpiece.</p>
          <button 
            onClick={onClose}
            className="mt-12 btn-3d-play px-12 py-4 text-base font-black rounded-3xl shadow-[0_20px_50px_rgba(255,122,24,0.3)]"
          >
            Explore Library
          </button>
        </div>
      ) : (
        <div 
          ref={containerRef}
          className="h-full w-full snap-y snap-mandatory overflow-y-auto no-scrollbar"
        >
          {reels.map((reel, i) => (
            <ReelItem 
              key={reel.id} 
              movie={reel} 
              isActive={i === activeIndex} 
            />
          ))}
          
          {/* Global Header */}
          <div className="fixed top-0 left-0 right-0 z-[110] p-6 pt-14 flex items-center justify-between pointer-events-none">
            <div className="flex items-center gap-3">
               <div className="h-10 w-10 flex items-center justify-center rounded-2xl bg-white/10 border border-white/15 backdrop-blur-3xl">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
                    <rect x="2" y="2" width="20" height="20" rx="2" />
                    <path d="m15 2-3.5 10L8 2M2 12h20M2 7h20M7 12l5 5 5-5" />
                  </svg>
               </div>
               <h2 className="font-display text-2xl tracking-[0.15em] text-white drop-shadow-[0_4px_12px_rgba(0,0,0,1)]">REELS</h2>
            </div>
            <button 
              onClick={onClose}
              className="pointer-events-auto flex h-12 w-12 items-center justify-center rounded-full bg-black/40 border border-white/15 text-white backdrop-blur-[60px] transition-all active:scale-75 shadow-2xl"
            >
              <XIcon className="h-6 w-6" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
