import { useState } from "react";
import { formatBytes, type MovieEntry } from "../telegram";
import { useUploads, refreshMoviesFromCloud } from "../hooks/useUploads";
import { fallbackPoster } from "../metadataBrain";
import { PlayIcon, StarIcon } from "../icons";
import { useReveal } from "../hooks";
import { useMovieContext } from "../movieContext";

// ─── Featured Hero-Style Upload Card ───
function FeaturedUpload({ movie, onOpen }: { movie: MovieEntry; onOpen: (m: MovieEntry) => void }) {
  return (
    <button
      onClick={() => onOpen(movie)}
      className="group relative h-56 w-40 shrink-0 cursor-pointer overflow-hidden rounded-2xl border border-white/10 bg-[#1a1a1e] shadow-xl transition-all duration-500 hover:-translate-y-2 hover:border-white/25 hover:shadow-[0_16px_40px_-12px_rgba(255,255,255,0.25)] active:scale-[0.98]"
    >
      <img
        src={movie.poster || fallbackPoster(movie.title, movie.genres, movie.year)}
        alt={movie.title}
        className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.1]"
        onError={(e) => {
          const t = e.target as HTMLImageElement;
          t.src = fallbackPoster(movie.title, movie.genres, movie.year);
        }}
      />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/95 via-black/30 to-black/30" />

      <div className="absolute left-2 top-2 flex items-center gap-1 rounded-full bg-emerald-500/30 px-2 py-1 backdrop-blur-md">
        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-300" />
        <span className="text-[9px] font-bold uppercase tracking-wider text-emerald-100">Live</span>
      </div>

      <div className="absolute right-2 top-2 flex items-center gap-1 rounded-full bg-black/60 px-2 py-0.5 backdrop-blur-md">
        <StarIcon className="h-3 w-3 text-amber-300" />
        <span className="text-[10px] font-bold text-white">NEW</span>
      </div>

      <div className="absolute inset-0 flex items-center justify-center opacity-0 transition-opacity group-hover:opacity-100">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-white shadow-2xl shadow-white/30">
          <PlayIcon className="ml-0.5 h-7 w-7 text-black" />
        </div>
      </div>

      <div className="absolute inset-x-0 bottom-0 p-3">
        <p className="truncate text-sm font-bold text-white drop-shadow">{movie.title}</p>
        <div className="mt-1 flex items-center gap-1.5 text-[10px] text-zinc-300">
          <span>{movie.year}</span>
          <span>·</span>
          <span>{movie.genres[0] || "Movie"}</span>
        </div>
        <div className="mt-1.5 flex items-center gap-1 text-[9px] text-zinc-400">
          <span>{formatBytes(movie.fileSize)}</span>
        </div>
      </div>
    </button>
  );
}

export default function CommunityUploads() {
  const movies = useUploads();
  const { ref, inView } = useReveal<HTMLElement>(0.1);
  const ctx = useMovieContext();
  const [recovering, setRecovering] = useState(false);
  const [recoveredMsg, setRecoveredMsg] = useState("");

  const handleRecover = async () => {
    setRecovering(true);
    setRecoveredMsg("");
    try {
      const m = await refreshMoviesFromCloud();
      setRecoveredMsg(`✓ ${m.length} movies loaded from cloud`);
      setTimeout(() => setRecoveredMsg(""), 3000);
    } catch {
      setRecoveredMsg("Sync failed — retry");
      setTimeout(() => setRecoveredMsg(""), 3000);
    } finally {
      setRecovering(false);
    }
  };

  const handleOpen = (m: MovieEntry) => {
    ctx.openMovie({
      id: m.id,
      title: m.title,
      poster: m.poster,
      backdrop: m.poster,
      year: m.year,
      rating: m.rating || "AI",
      genres: m.genres,
      overview: m.overview,
      isUpload: true,
      entry: m,
    });
  };

  if (movies.length === 0 && !recovering) return null;

  return (
    <section ref={ref} className={`mt-8 ${inView ? "in-view" : ""} reveal`}>
      <div className="flex items-end justify-between px-5">
        <div>
          <h2 className="section-accent text-lg font-bold tracking-tight text-white">
            Your Uploads
          </h2>
          <p className="mt-1 text-[10px] text-zinc-500">
            {recoveredMsg || "Permanently stored on Telegram"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleRecover}
            disabled={recovering}
            className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-[10px] font-bold text-zinc-300 backdrop-blur-md transition-all hover:bg-white/10 active:scale-95 disabled:opacity-60"
          >
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" className={recovering ? "animate-spin" : ""}>
              <path d="M21 12a9 9 0 1 1-3-6.7L21 8" />
              <path d="M21 3v5h-5" />
            </svg>
            {recovering ? "Restoring" : "Restore"}
          </button>
          <span className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-bold ${
            movies.length > 0
              ? "border-emerald-400/30 bg-emerald-400/15 text-emerald-300"
              : "border-white/10 bg-white/5 text-zinc-500"
          }`}>
            {movies.length > 0 ? `${movies.length} live` : "0 live"}
          </span>
        </div>
      </div>

      <div className="no-scrollbar mt-4 flex gap-3.5 overflow-x-auto px-5 pb-2">
        {movies.map((m) => (
          <FeaturedUpload key={m.id} movie={m} onOpen={handleOpen} />
        ))}
      </div>
    </section>
  );
}

// Used by MovieRow to inject upload cards
export function UploadPosterCard({ movie, large = false }: { movie: MovieEntry; large?: boolean }) {
  const ctx = useMovieContext();
  const [hover, setHover] = useState(false);

  const handleOpen = () => {
    ctx.openMovie({
      id: movie.id,
      title: movie.title,
      poster: movie.poster,
      backdrop: movie.poster,
      year: movie.year,
      rating: movie.rating || "AI",
      genres: movie.genres,
      overview: movie.overview,
      isUpload: true,
      entry: movie,
    });
  };

  return (
    <button
      onClick={handleOpen}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      className={`group relative shrink-0 cursor-pointer overflow-hidden rounded-2xl border border-white/10 bg-[#1a1a1e] shadow-xl transition-all duration-500 hover:-translate-y-2 hover:border-white/25 active:scale-[0.98] ${
        large ? "h-56 w-40" : "h-44 w-32"
      }`}
    >
      <img
        src={movie.poster || fallbackPoster(movie.title, movie.genres, movie.year)}
        alt={movie.title}
        className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.08]"
        onError={(e) => {
          const t = e.target as HTMLImageElement;
          t.src = fallbackPoster(movie.title, movie.genres, movie.year);
        }}
      />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />

      <div className="absolute left-2 top-2 flex items-center gap-1 rounded-full bg-emerald-500/30 px-1.5 py-0.5 backdrop-blur-md">
        <span className="h-1 w-1 animate-pulse rounded-full bg-emerald-300" />
        <span className="text-[8px] font-bold text-emerald-100">LIVE</span>
      </div>

      <div className={`absolute inset-0 flex items-center justify-center transition-opacity ${hover ? "opacity-100" : "opacity-0"}`}>
        <div className="flex h-11 w-11 items-center justify-center rounded-full bg-white shadow-xl">
          <PlayIcon className="ml-0.5 h-5 w-5 text-black" />
        </div>
      </div>

      <div className="absolute inset-x-0 bottom-0 p-2.5">
        <p className="truncate text-xs font-semibold text-white drop-shadow">{movie.title}</p>
        <p className="text-[10px] text-zinc-400">{movie.year} · {movie.genres[0] || "Community"}</p>
      </div>
    </button>
  );
}
