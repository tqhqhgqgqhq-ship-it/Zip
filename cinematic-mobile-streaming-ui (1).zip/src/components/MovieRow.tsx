import type { Movie } from "../data";
import { movieNames } from "../data";
import { fallbackPoster } from "../metadataBrain";
import { StarIcon, ChevronRight, PlusIcon } from "../icons";
import { useReveal } from "../hooks";
import { useUploads } from "../hooks/useUploads";
import { UploadPosterCard } from "./CommunityUploads";
import { useMovieContext } from "../movieContext";

export default function MovieRow({
  title,
  movies,
  large = false,
  ranked = false,
  showUploads = false,
}: {
  title: string;
  movies: Movie[];
  large?: boolean;
  ranked?: boolean;
  showUploads?: boolean;
}) {
  const { ref, inView } = useReveal<HTMLDivElement>(0.1);
  const uploads = useUploads();
  const ctx = useMovieContext();

  const uploadsToShow = showUploads ? uploads.filter(m => !m.isReel) : [];

  const handleDemoClick = (m: Movie, i: number) => {
    const movieTitle = movieNames[(i + title.length) % movieNames.length] || "Movie";
    ctx.openMovie({
      id: `demo-${m.id}`,
      title: movieTitle,
      poster: m.poster,
      backdrop: m.poster,
      year: m.year,
      rating: m.rating,
      genres: [m.genre.split("·")[0].trim()],
      duration: m.duration,
      overview: `Experience ${movieTitle}, a cinematic masterpiece that pushes the boundaries of storytelling.`,
      isUpload: false,
    });
  };

  if (movies.length === 0 && uploadsToShow.length === 0) return null;

  return (
    <section ref={ref} className={`mt-8 ${inView ? "in-view" : ""} reveal`}>
      <div className="flex items-end justify-between px-5">
        <div className="flex items-center gap-2">
          <h2 className="section-accent text-lg font-bold tracking-tight text-white">
            {title}
          </h2>
          {showUploads && uploadsToShow.length > 0 && (
            <span className="rounded-full border border-emerald-400/30 bg-emerald-400/15 px-1.5 py-0.5 text-[9px] font-bold text-emerald-300">
              +{uploadsToShow.length}
            </span>
          )}
        </div>
        <button className="flex items-center gap-0.5 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-medium text-zinc-300 backdrop-blur-md transition-all hover:bg-white/10 hover:text-white active:scale-95">
          See all <ChevronRight className="h-3.5 w-3.5" />
        </button>
      </div>

      <div className="no-scrollbar mt-4 flex gap-3.5 overflow-x-auto px-5 pb-2 scroll-smooth-snap">
        {/* Uploaded community movies first */}
        {uploadsToShow.map((upload) => (
          <UploadPosterCard
            key={`upload-${upload.id}`}
            movie={upload}
            large={large}
          />
        ))}

        {/* Standard demo movies */}
        {movies.map((m, i) => (
          <button
            key={m.id}
            onClick={() => handleDemoClick(m, i)}
            className="group relative shrink-0 cursor-pointer text-left"
            style={{
              scrollSnapAlign: "start",
              animationDelay: `${i * 60}ms`,
            }}
          >
            {ranked && (
              <span
                className="absolute -left-2 bottom-8 z-10 font-display text-6xl leading-none select-none"
                style={{
                  WebkitTextStroke: "1.5px #ffb347",
                  color: "transparent",
                  textShadow: "0 4px 20px rgba(255,179,71,0.3)",
                }}
              >
                {i + 1 + uploadsToShow.length}
              </span>
            )}
            <div
              className={`card-shine relative overflow-hidden rounded-2xl border border-white/10 bg-[#1a1a1e] shadow-xl transition-all duration-500 ease-out group-hover:-translate-y-2 group-hover:border-white/25 group-hover:shadow-[0_16px_40px_-12px_rgba(255,122,24,0.35)] ${
                large ? "h-56 w-40" : "h-44 w-32"
              } ${ranked ? "ml-7" : ""}`}
            >
              <img
                src={m.poster}
                alt=""
                loading="lazy"
                decoding="async"
                className="h-full w-full object-contain transition-transform duration-700 ease-out group-hover:scale-[1.08]"
                draggable={false}
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  const movieTitle = movieNames[(i + title.length) % movieNames.length] || "Movie";
                  if (target.src !== fallbackPoster(movieTitle, [m.genre.split("·")[0].trim()], m.year)) {
                    target.src = fallbackPoster(movieTitle, [m.genre.split("·")[0].trim()], m.year);
                  }
                }}
              />
              <div className="pointer-events-none absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
              <div className="pointer-events-none absolute inset-x-0 top-0 h-1/3 bg-gradient-to-b from-black/40 to-transparent" />

              <div className="absolute left-2 top-2 flex items-center gap-1 rounded-full bg-black/60 px-2 py-0.5 backdrop-blur-md transition-transform duration-300 group-hover:scale-105">
                <StarIcon className="h-2.5 w-2.5 text-amber-400" />
                <span className="text-[10px] font-bold text-white">{m.rating}</span>
              </div>

              <div className="absolute right-2 top-2 opacity-0 transition-all duration-300 group-hover:opacity-100">
                <div className="flex h-7 w-7 items-center justify-center rounded-full bg-white/15 backdrop-blur-md border border-white/20">
                  <PlusIcon className="h-4 w-4 text-white" />
                </div>
              </div>

              <div className="absolute inset-x-0 bottom-0 p-2.5 transition-transform duration-300 group-hover:translate-y-0">
                <p className="truncate text-xs font-semibold text-white drop-shadow">
                  {movieNames[(i + title.length) % movieNames.length]}
                </p>
                <p className="text-[10px] text-zinc-300/80">
                  {m.year} · {m.genre.split("·")[0].trim()}
                </p>
              </div>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
}
