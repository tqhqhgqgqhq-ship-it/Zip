import { useState } from "react";
import { HomeIcon, PlusIcon, ReelsIcon, UserIcon } from "../icons";

const left = [
  { key: "home", Icon: HomeIcon },
  { key: "reels", Icon: ReelsIcon },
];

const right = [
  { key: "profile", Icon: UserIcon },
];

export default function BottomNav({
  activeTab,
  onChangeTab,
  onUpload,
}: {
  activeTab: string;
  onChangeTab: (tab: any) => void;
  onUpload: () => void;
}) {
  const [key, setKey] = useState(0);

  const renderTab = (k: string, Icon: typeof HomeIcon) => {
    const on = k === activeTab;
    return (
      <button
        key={k}
        onClick={() => {
          onChangeTab(k);
          setKey((x) => x + 1);
        }}
        className={`relative flex h-12 w-12 items-center justify-center rounded-full transition-all duration-500 ${
          on ? "text-black" : "text-zinc-500 hover:text-white"
        }`}
      >
        {on && (
          <span
            key={key}
            className="absolute inset-0 animate-spring rounded-full bg-white shadow-[0_10px_20px_rgba(255,255,255,0.3)]"
          />
        )}
        <Icon 
          className="relative h-[22px] w-[22px] transition-transform duration-500" 
          style={{ transform: on ? "scale(1.1)" : "scale(1)" }}
          strokeWidth={on ? 2.5 : 1.8} 
        />
      </button>
    );
  };

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-[80] flex justify-center pb-6">
      <div className="pointer-events-auto relative flex items-center gap-1 rounded-[32px] border border-white/10 bg-black/40 px-2 py-2 backdrop-blur-3xl shadow-2xl shadow-black/80">
        {/* Left tabs */}
        {left.map(({ key: k, Icon }) => renderTab(k, Icon))}

        {/* Center floating + button */}
        <div className="relative -mt-8 mx-2">
          <button
            onClick={onUpload}
            className="group relative z-10 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-orange-400 to-orange-600 text-white shadow-[0_12px_32px_rgba(255,122,24,0.4)] transition-all duration-500 hover:scale-110 hover:-translate-y-1 active:scale-90"
          >
            <div className="absolute inset-0 rounded-full bg-orange-400 blur-xl opacity-20 group-hover:opacity-40 animate-pulse" />
            <PlusIcon className="relative h-8 w-8 transition-transform duration-500 group-hover:rotate-90" strokeWidth={3} />
          </button>
        </div>

        {/* Right tabs */}
        {right.map(({ key: k, Icon }) => renderTab(k, Icon))}
      </div>
    </div>
  );
}
