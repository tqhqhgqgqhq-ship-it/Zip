import { useEffect, useRef, useState, useCallback } from "react";
import {
  VolumeIcon, VolumeMuteIcon, SunIcon,
  Forward10Icon, Backward10Icon, LockIcon,
  UnlockIcon, PiPIcon, ChevronDownIcon, SettingsIcon, CheckCircleIcon,
} from "../icons";
import { getBlobStreamUrl, getStreamUrl, type StreamProgress } from "../telegram";
import { incrementWatchInCloud } from "../cloudStorage";
import type { OpenMovieData } from "../movieContext";
import LiquidProgressBar from "./LiquidProgressBar";
import MorphPlayButton from "./MorphPlayButton";

function fmt(s: number): string {
  if (!isFinite(s) || s < 0) return "0:00";
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`
    : `${m}:${String(sec).padStart(2, "0")}`;
}

// ─── Vertical liquid slider (volume / brightness) ───
function VSlider({ value, onChange, color }: { value: number; onChange: (v: number) => void; color: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [drag, setDrag] = useState(false);

  const calc = (cy: number) => {
    const el = ref.current; if (!el) return value;
    const r = el.getBoundingClientRect();
    return Math.max(0, Math.min(1, 1 - (cy - r.top) / r.height));
  };

  useEffect(() => {
    if (!drag) return;
    const mm = (e: MouseEvent) => onChange(calc(e.clientY));
    const tm = (e: TouchEvent) => onChange(calc(e.touches[0].clientY));
    const up = () => setDrag(false);
    window.addEventListener("mousemove", mm);
    window.addEventListener("mouseup", up);
    window.addEventListener("touchmove", tm, { passive: true });
    window.addEventListener("touchend", up);
    return () => {
      window.removeEventListener("mousemove", mm);
      window.removeEventListener("mouseup", up);
      window.removeEventListener("touchmove", tm);
      window.removeEventListener("touchend", up);
    };
  }, [drag, onChange]);

  return (
    <div
      ref={ref}
      className="lg-vslider"
      style={{ width: drag ? 12 : 6, height: 120 }}
      onMouseDown={(e) => { setDrag(true); onChange(calc(e.clientY)); }}
      onTouchStart={(e) => { setDrag(true); onChange(calc(e.touches[0].clientY)); }}
    >
      <div
        className="lg-vslider-fill"
        style={{
          height: `${value * 100}%`,
          background: color,
          boxShadow: `0 0 12px ${color}aa`,
          transition: drag ? "none" : "height 0.1s linear",
        }}
      />
    </div>
  );
}

export default function CinematicPlayer({ movie, onClose }: { movie: OpenMovieData; onClose: () => void }) {
  const vid = useRef<HTMLVideoElement>(null);

  const [url, setUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [sp, setSp] = useState<StreamProgress | null>(null);
  const [fallbackTried, setFallbackTried] = useState(false);

  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [dur, setDur] = useState(0);
  const [buf, setBuf] = useState(0);
  const [vol, setVol] = useState(1);
  const [muted, setMuted] = useState(false);
  const [bright, setBright] = useState(1);
  const [speed, setSpeed] = useState(1);
  const [showCtrl, setShowCtrl] = useState(true);
  const [locked, setLocked] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showVol, setShowVol] = useState(false);
  const [showBright, setShowBright] = useState(false);
  const [skipFlash, setSkipFlash] = useState<"left" | "right" | null>(null);
  const [closing, setClosing] = useState(false);
  const hideTimer = useRef<ReturnType<typeof setTimeout>>(undefined);

  // Resolve stream
  useEffect(() => {
    let dead = false;
    let objUrl: string | null = null;
    (async () => {
      try {
        if (movie.isUpload && movie.entry) {
          const u = await getStreamUrl(movie.entry, (p) => { if (!dead) setSp(p); });
          if (dead) return;
          setUrl(u);
          if (u.startsWith("blob:")) objUrl = u;
          incrementWatchInCloud(movie.entry.id);
        } else {
          setUrl(movie.demoVideoSrc || "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4");
        }
      } catch (e: any) {
        if (!dead) setError(e?.message || "Cannot load");
      } finally {
        if (!dead) setLoading(false);
      }
    })();
    return () => { dead = true; if (objUrl) URL.revokeObjectURL(objUrl); };
  }, [movie.id]);

  // Video events
  useEffect(() => {
    const v = vid.current;
    if (!v) return;
    const h = {
      play: () => setPlaying(true),
      pause: () => setPlaying(false),
      timeupdate: () => setTime(v.currentTime),
      loadedmetadata: () => setDur(v.duration || 0),
      progress: () => { if (v.buffered.length > 0) setBuf(v.buffered.end(v.buffered.length - 1)); },
    };
    Object.entries(h).forEach(([e, f]) => v.addEventListener(e, f));
    return () => { Object.entries(h).forEach(([e, f]) => v.removeEventListener(e, f)); };
  }, [url]);

  useEffect(() => { if (vid.current) vid.current.volume = vol; }, [vol]);
  useEffect(() => { if (vid.current) vid.current.muted = muted; }, [muted]);
  useEffect(() => { if (vid.current) vid.current.playbackRate = speed; }, [speed]);

  const resetHide = useCallback(() => {
    setShowCtrl(true);
    if (hideTimer.current) clearTimeout(hideTimer.current);
    if (playing && !locked && !showSettings) {
      hideTimer.current = setTimeout(() => setShowCtrl(false), 3800);
    }
  }, [playing, locked, showSettings]);
  useEffect(resetHide, [resetHide]);

  const togglePlay = () => {
    const v = vid.current;
    if (!v) return;
    if (v.paused) v.play().catch(() => undefined); else v.pause();
    resetHide();
  };

  const seek = (t: number) => {
    const v = vid.current;
    if (!v) return;
    v.currentTime = Math.max(0, Math.min(dur, t));
    setTime(v.currentTime);
  };

  const skip = (s: number) => {
    seek(time + s);
    setSkipFlash(s > 0 ? "right" : "left");
    setTimeout(() => setSkipFlash(null), 700);
    resetHide();
  };

  const controlTap = (e: React.SyntheticEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const stopOnly = (e: React.SyntheticEvent) => {
    e.stopPropagation();
  };

  // Tap zones
  const lastTap = useRef({ t: 0, s: "" });
  const handleScreenTapAt = (clientX: number, currentTarget: HTMLElement) => {
    if (locked) return;
    const rect = currentTarget.getBoundingClientRect();
    const relX = (clientX - rect.left) / rect.width;
    const side = relX < 0.3 ? "left" : relX > 0.7 ? "right" : "mid";
    const now = Date.now();
    if (now - lastTap.current.t < 300 && lastTap.current.s === side) {
      if (side === "left") skip(-10);
      else if (side === "right") skip(10);
      else togglePlay();
      lastTap.current = { t: 0, s: "" };
    } else {
      lastTap.current = { t: now, s: side };
      setTimeout(() => {
        if (lastTap.current.t === now) { setShowCtrl((v) => !v); resetHide(); }
      }, 280);
    }
  };

  const onScreenTap = (e: React.MouseEvent) => {
    handleScreenTapAt(e.clientX, e.currentTarget as HTMLElement);
  };

  const onScreenTouchEnd = (e: React.TouchEvent) => {
    if (!e.changedTouches.length) return;
    handleScreenTapAt(e.changedTouches[0].clientX, e.currentTarget as HTMLElement);
  };

  const dlPct = sp ? Math.round((sp.bytesLoaded / Math.max(sp.bytesTotal, 1)) * 100) : 0;
  const handleClose = () => {
    const v = vid.current;
    if (v) {
      try { v.pause(); } catch {}
      try { v.removeAttribute("src"); v.load(); } catch {}
    }
    setClosing(true);
    window.setTimeout(onClose, 120);
  };

  useEffect(() => {
    const onResize = () => {
      setShowCtrl(true);
      resetHide();
    };
    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", onResize);
    };
  }, [resetHide]);

  const handleVideoError = async () => {
    const mediaError = vid.current?.error;
    console.warn("[Player] Media playback error:", mediaError?.code, mediaError?.message);

    if (movie.isUpload && movie.entry && !fallbackTried) {
      setFallbackTried(true);
      setLoading(true);
      setError("");
      try {
        const blobUrl = await getBlobStreamUrl(movie.entry);
        setUrl(blobUrl);
        window.setTimeout(() => {
          vid.current?.play().catch(() => undefined);
        }, 50);
        return;
      } catch (err: any) {
        console.error("[Player] Blob fallback failed:", err);
      } finally {
        setLoading(false);
      }
    }

    setError(
      mediaError?.code === 4
        ? "This file format is not playable in the browser. Please upload MP4/H.264 for streaming playback."
        : "Playback error. Media could not be played."
    );
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") handleClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const togglePip = async () => {
    try {
      if (document.pictureInPictureElement) await document.exitPictureInPicture();
      else if (vid.current) await (vid.current as any).requestPictureInPicture();
    } catch { /* unsupported */ }
  };

  // When paused, deepen the cinematic dim
  const dimOpacity = !playing && !loading ? 1 : 0;

  return (
    <div className={`fixed inset-0 z-[100] bg-black ${closing ? "animate-details-out" : "animate-player-enter"}`}>
      {/* Video stage */}
      <div
        className="absolute inset-0 flex items-center justify-center"
        style={{ filter: `brightness(${bright})` }}
        onClick={onScreenTap}
        onTouchEnd={onScreenTouchEnd}
      >
        {url && (
          <video
            ref={vid}
            src={url}
            autoPlay
            playsInline
            className="h-full w-full object-contain"
            onError={handleVideoError}
            onCanPlay={() => setLoading(false)}
          />
        )}
      </div>

      {/* Cinematic dim when paused */}
      <div className="lg-dim" style={{ opacity: dimOpacity }} />

      {/* Always available back button, independent from auto-hidden controls */}
      <button
        onClick={(e) => { controlTap(e); handleClose(); }}
        onPointerDown={stopOnly}
        className="lg-ctrl pointer-events-auto absolute left-4 top-4 z-[60] h-11 w-11"
        aria-label="Back to details"
      >
        <ChevronDownIcon className="h-5 w-5 text-white" />
      </button>

      {/* Loading */}
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black">
          <div className="text-center">
            <div className="relative mx-auto h-16 w-16">
              <div className="absolute inset-0 animate-spin rounded-full border-2 border-white/15 border-t-white" />
            </div>
            <p className="mt-5 text-sm font-bold text-white">
              {movie.entry?.isChunked ? "Assembling cinematic stream" : "Preparing stream"}
            </p>
            {sp && movie.entry?.isChunked && (
              <>
                <p className="mt-2 text-xs text-zinc-400">Part {sp.chunkIndex} of {sp.totalChunks}</p>
                <div className="mx-auto mt-3 h-1 w-48 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full bg-white" style={{ width: `${dlPct}%`, boxShadow: "0 0 12px rgba(255,255,255,0.5)" }} />
                </div>
                <p className="mt-1.5 text-[10px] text-zinc-500">{dlPct}%</p>
              </>
            )}
          </div>
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center px-6 text-center">
          <div>
            <p className="text-base font-bold text-white">Playback unavailable</p>
            <p className="mt-2 text-xs text-zinc-400">{error}</p>
            <button onClick={handleClose} className="btn-3d-play mt-6 rounded-2xl px-6 py-2.5 text-sm font-bold">Back</button>
          </div>
        </div>
      )}

      {/* Skip ripple */}
      {skipFlash && (
        <div className={`pointer-events-none absolute top-1/2 -translate-y-1/2 ${skipFlash === "left" ? "left-10" : "right-10"}`}>
          <div className="lg-skip-ripple flex h-20 w-20 items-center justify-center rounded-full bg-white/12 backdrop-blur-xl border border-white/20">
            {skipFlash === "left" ? <Backward10Icon className="h-8 w-8 text-white" /> : <Forward10Icon className="h-8 w-8 text-white" />}
          </div>
        </div>
      )}

      {/* Locked overlay */}
      {locked && (
        <div className="absolute inset-0 z-30 flex items-center justify-center" onClick={(e) => e.stopPropagation()}>
          <button onClick={() => setLocked(false)} className="lg-ctrl h-16 w-16">
            <UnlockIcon className="h-7 w-7 text-white" />
          </button>
        </div>
      )}

      {/* Controls */}
      {!locked && !error && (
        <div className={`lg-controls pointer-events-none absolute inset-0 z-20`} style={{ opacity: showCtrl ? 1 : 0 }}>
          {/* Top scrim + bar */}
          <div className="lg-scrim-top pointer-events-auto absolute inset-x-0 top-0 flex items-start justify-between p-4 pb-8">
            <button onClick={(e) => { controlTap(e); handleClose(); }} onPointerDown={stopOnly} className="lg-ctrl h-11 w-11">
              <ChevronDownIcon className="h-5 w-5 text-white" />
            </button>
            <div className="px-3 text-center">
              <p className="text-[10px] font-bold uppercase tracking-[0.28em] text-white/55">Now Playing</p>
              <h3 className="mt-0.5 max-w-[200px] truncate text-sm font-black text-white drop-shadow">{movie.title}</h3>
            </div>
            <button onClick={(e) => { controlTap(e); togglePip(); }} onPointerDown={stopOnly} className="lg-ctrl h-11 w-11">
              <PiPIcon className="h-5 w-5 text-white" />
            </button>
          </div>

          {/* Center: skip + morph play */}
          <div className="pointer-events-auto absolute inset-0 z-50 flex items-center justify-center gap-10" style={{ touchAction: "manipulation" }}>
            <button onClick={(e) => { controlTap(e); skip(-10); }} onPointerDown={stopOnly} className="lg-ctrl h-14 w-14">
              <Backward10Icon className="h-7 w-7 text-white" />
            </button>
            <MorphPlayButton playing={playing} onToggle={togglePlay} size={92} />
            <button onClick={(e) => { controlTap(e); skip(10); }} onPointerDown={stopOnly} className="lg-ctrl h-14 w-14">
              <Forward10Icon className="h-7 w-7 text-white" />
            </button>
          </div>

          {/* Volume slider */}
          {showVol && (
            <div className="pointer-events-auto absolute right-5 top-1/2 -translate-y-1/2 flex flex-col items-center gap-3 rounded-3xl glass-control px-3 py-4 animate-fade-up">
              <VSlider value={muted ? 0 : vol} onChange={(v) => { setVol(v); setMuted(v === 0); }} color="#ffffff" />
              <button onClick={(e) => { controlTap(e); setMuted(!muted); }} onPointerDown={stopOnly} className="lg-ctrl h-9 w-9">
                {muted || vol === 0 ? <VolumeMuteIcon className="h-4 w-4 text-white" /> : <VolumeIcon className="h-4 w-4 text-white" />}
              </button>
            </div>
          )}

          {/* Brightness slider */}
          {showBright && (
            <div className="pointer-events-auto absolute left-5 top-1/2 -translate-y-1/2 flex flex-col items-center gap-3 rounded-3xl glass-control px-3 py-4 animate-fade-up">
              <VSlider value={bright} onChange={setBright} color="#ffd27a" />
              <div className="lg-ctrl h-9 w-9"><SunIcon className="h-4 w-4 text-amber-200" /></div>
            </div>
          )}

          {/* Bottom scrim + progress + controls */}
          <div className="lg-scrim-bottom pointer-events-auto absolute inset-x-0 bottom-0 px-5 pb-5 pt-12">
            {/* Time row */}
            <div className="mb-3 flex items-center justify-between text-[11px] font-bold tabular-nums text-white/90">
              <span>{fmt(time)}</span>
              <span className="rounded-full bg-white/10 px-2 py-0.5 text-[10px] text-white/70 backdrop-blur">
                -{fmt(Math.max(0, dur - time))}
              </span>
              <span>{fmt(dur)}</span>
            </div>

            {/* LIQUID GLASS PROGRESS BAR */}
            <LiquidProgressBar
              current={time}
              duration={dur}
              buffered={buf}
              poster={movie.poster}
              onSeek={(t) => { seek(t); resetHide(); }}
            />

            {/* Control row */}
            <div className="mt-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <button onClick={(e) => { controlTap(e); setShowVol((v) => !v); }} onPointerDown={stopOnly} className={`lg-ctrl h-10 w-10 ${showVol ? "active" : ""}`}>
                  {muted || vol === 0 ? <VolumeMuteIcon className="h-[18px] w-[18px]" /> : <VolumeIcon className="h-[18px] w-[18px]" />}
                </button>
                <button onClick={(e) => { controlTap(e); setShowBright((v) => !v); }} onPointerDown={stopOnly} className={`lg-ctrl h-10 w-10 ${showBright ? "active" : ""}`}>
                  <SunIcon className="h-[18px] w-[18px]" />
                </button>
              </div>

              <div className="flex items-center gap-2.5">
                <button onClick={(e) => { controlTap(e); setLocked(true); }} onPointerDown={stopOnly} className="lg-ctrl h-10 w-10">
                  <LockIcon className="h-[18px] w-[18px]" />
                </button>
                <button onClick={(e) => { controlTap(e); setShowSettings(true); resetHide(); }} onPointerDown={stopOnly} className="lg-ctrl h-10 w-10">
                  <SettingsIcon className="h-[18px] w-[18px]" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Settings sheet */}
      {showSettings && (
        <div className="absolute inset-0 z-40 flex items-end" onClick={() => setShowSettings(false)}>
          <div className="absolute inset-0 bg-black/50 backdrop-blur-md" />
          <div
            className="relative w-full max-h-[80%] overflow-y-auto rounded-t-[32px] border-t border-white/10 bg-[#0a0a0c]/95 p-5 backdrop-blur-2xl no-scrollbar animate-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mx-auto mb-4 h-1 w-12 rounded-full bg-white/20" />
            <h3 className="text-lg font-black text-white">Player Settings</h3>

            <SettingsGroup title="Playback Speed">
              <Pills options={["0.5×", "0.75×", "1×", "1.25×", "1.5×", "2×"]} value={`${speed}×`} onChange={(v) => setSpeed(parseFloat(v))} />
            </SettingsGroup>
            <SettingsGroup title="Quality">
              <Pills options={["Auto", "1080p", "720p", "480p"]} value="Auto" onChange={() => {}} />
            </SettingsGroup>
            <SettingsGroup title="Subtitles">
              <Pills options={["Off", "English", "Spanish", "Hindi"]} value="Off" onChange={() => {}} />
            </SettingsGroup>
            <SettingsGroup title="Audio Track">
              <Pills options={["Original", "English Dub"]} value="Original" onChange={() => {}} />
            </SettingsGroup>
          </div>
        </div>
      )}
    </div>
  );
}

function SettingsGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-5">
      <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-400">{title}</p>
      <div className="mt-2.5">{children}</div>
    </div>
  );
}

function Pills({ options, value, onChange }: { options: string[]; value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((o) => {
        const on = o === value;
        return (
          <button
            key={o}
            onClick={() => onChange(o)}
            className={`flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-semibold transition-all active:scale-95 ${
              on ? "bg-white text-black" : "border border-white/10 bg-white/5 text-zinc-300 hover:bg-white/10"
            }`}
          >
            {on && <CheckCircleIcon className="h-3 w-3" />}
            {o}
          </button>
        );
      })}
    </div>
  );
}
