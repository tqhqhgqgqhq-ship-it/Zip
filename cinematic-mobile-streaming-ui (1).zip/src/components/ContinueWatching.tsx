import { continueWatching } from "../data";
import { PlayIcon } from "../icons";
import { useReveal } from "../hooks";
import { fallbackPoster } from "../metadataBrain";

export default function ContinueWatching() {
  const { ref, inView } = useReveal<HTMLElement>(0.1);
  return (
    <section ref={ref} className={`mt-8 ${inView ? "in-view" : ""} reveal`}>
      <div className="flex items-end justify-between px-5">
        <h2 className="section-accent text-lg font-bold tracking-tight text-white">
          Continue Watching
        </h2>
        <button className="flex items-center gap-0.5 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-medium text-zinc-300 backdrop-blur-md transition-all hover:bg-white/10 hover:text-white active:scale-95">
          See all
        </button>
      </div>

      <div className="no-scrollbar mt-4 flex gap-3.5 overflow-x-auto px-5 pb-2 scroll-smooth-snap">
        {continueWatching.map((m, i) => (
          <div
            key={m.id}
            className="card-shine group relative h-28 w-48 shrink-0 cursor-pointer overflow-hidden rounded-2xl border border-white/10 bg-[#1a1a1e] shadow-xl transition-all duration-500 ease-out hover:-translate-y-1.5 hover:shadow-[0_16px_40px_-12px_rgba(255,122,24,0.3)]"
            style={{ scrollSnapAlign: "start", animationDelay: `${i * 80}ms` }}
          >
            {/* Poster fit */}
            <img
              src={m.poster}
              alt=""
              loading="lazy"
              decoding="async"
              className="h-full w-full object-contain transition-transform duration-700 group-hover:scale-110"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                if (target.src !== fallbackPoster(m.name, [], undefined)) {
                  target.src = fallbackPoster(m.name, [], undefined);
                }
              }}
            />
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/95 via-black/30 to-black/30" />

            {/* Center play button */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="relative flex h-11 w-11 items-center justify-center rounded-full bg-white/10 backdrop-blur-md border border-white/20 transition-all duration-300 group-hover:scale-110 group-hover:bg-white/20">
                <div
                  className="absolute inset-0 rounded-full animate-glow-pulse"
                  style={{
                    background: `radial-gradient(circle, rgba(255,122,24,0.4), transparent 70%)`,
                  }}
                />
                <PlayIcon className="relative ml-0.5 h-5 w-5 text-white drop-shadow" />
              </div>
            </div>

            {/* Bottom info */}
            <div className="absolute inset-x-0 bottom-0 p-2.5">
              <p className="truncate text-xs font-semibold text-white drop-shadow">{m.name}</p>
              <p className="text-[10px] text-zinc-300/80">
                {Math.round(m.progress * 100)}% watched
              </p>
              <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-white/15 backdrop-blur">
                <div
                  className="shimmer-progress h-full rounded-full"
                  style={{
                    width: `${m.progress * 100}%`,
                  }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
