import { useLiquidPhysics } from "../hooks/useLiquidPhysics";
import { useEffect, useRef } from "react";

function fmt(s: number): string {
  if (!isFinite(s) || s < 0) return "0:00";
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  return `${m}:${String(sec).padStart(2, "0")}`;
}

export default function LiquidProgressBar({
  current,
  duration,
  buffered,
  poster,
  onSeek,
}: {
  current: number;
  duration: number;
  buffered: number;
  poster?: string;
  onSeek: (time: number) => void;
}) {
  const handleSeek = (frac: number) => onSeek(frac * duration);
  const { trackRef, state, start, move, end, setExternalFraction } = useLiquidPhysics(handleSeek);
  const movedRef = useRef(false);

  // Sync playback position into the physics state when not dragging
  useEffect(() => {
    if (!state.dragging) {
      setExternalFraction(duration > 0 ? current / duration : 0);
    }
  }, [current, duration, state.dragging, setExternalFraction]);

  // Global listeners while dragging
  useEffect(() => {
    if (!state.dragging) return;
    const mm = (e: MouseEvent) => { movedRef.current = true; move(e.clientX); };
    const tm = (e: TouchEvent) => { movedRef.current = true; move(e.touches[0].clientX); };
    const up = () => end();
    window.addEventListener("mousemove", mm);
    window.addEventListener("mouseup", up);
    window.addEventListener("touchmove", tm, { passive: true });
    window.addEventListener("touchend", up);
    return () => {
      window.removeEventListener("mousemove", mm);
      window.removeEventListener("mouseup", up);
      window.removeEventListener("touchmove", tm);
      window.removeEventListener("touchend", up);
    };
  }, [state.dragging, move, end]);

  const fraction = state.fraction;
  const bufFrac = duration > 0 ? buffered / duration : 0;
  const previewTime = fraction * duration;

  // Physics-derived visuals
  const dragging = state.dragging;
  const baseHeight = dragging ? 16 : 5;
  const squashHeight = baseHeight * (1 - state.squash * 0.45); // squeeze height under velocity
  const stretchX = state.stretchX;
  const handleSize = dragging ? 22 * (1 - state.squash * 0.3) : 0;
  const handleWidth = handleSize * stretchX; // elongate handle under velocity

  return (
    <div
      ref={trackRef}
      className="lg-track"
      style={{ height: 26, paddingTop: 5, paddingBottom: 5 }}
      onMouseDown={(e) => { movedRef.current = false; start(e.clientX); }}
      onTouchStart={(e) => { movedRef.current = false; start(e.touches[0].clientX); }}
    >
      {/* Floating preview card */}
      {dragging && (
        <>
          <div
            className="lg-preview"
            style={{
              left: `${Math.max(8, Math.min(92, fraction * 100))}%`,
              width: 132,
              height: 78,
              opacity: 1,
              transform: `translateX(-50%) scale(${1 - state.squash * 0.06})`,
            }}
          >
            {poster ? (
              <img
                src={poster}
                alt=""
                className="h-full w-full object-cover"
                style={{ filter: `brightness(0.85) blur(${state.blur * 0.4}px)` }}
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-zinc-900 text-zinc-600">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <rect x="2" y="2" width="20" height="20" rx="2.18" />
                  <path d="M7 2v20M17 2v20M2 12h20" />
                </svg>
              </div>
            )}
            <div className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-white/10" />
          </div>
          <div
            className="lg-time-bubble"
            style={{ left: `${Math.max(6, Math.min(94, fraction * 100))}%` }}
          >
            {fmt(previewTime)} <span className="opacity-40">/ {fmt(duration)}</span>
          </div>
        </>
      )}

      {/* The glass pill */}
      <div
        className={`lg-pill ${dragging ? "dragging" : ""}`}
        style={{
          height: squashHeight,
          transform: dragging ? `translateY(-3px)` : "none",
          transition: dragging ? "none" : "height 0.4s cubic-bezier(0.34,1.56,0.64,1), transform 0.4s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.4s ease",
        }}
      >
        <div className="lg-buffer" style={{ width: `${bufFrac * 100}%` }} />
        <div
          className="lg-fill"
          style={{
            width: `${fraction * 100}%`,
            transition: dragging ? "none" : "width 0.12s linear",
          }}
        />
        {/* Handle blob */}
        {dragging && (
          <div
            className="lg-handle"
            style={{
              left: `${fraction * 100}%`,
              width: handleWidth,
              height: handleSize,
              transform: `translate(-50%, -50%) skewX(${-state.velocity * 8}deg)`,
              transition: "none",
            }}
          />
        )}
      </div>
    </div>
  );
}
