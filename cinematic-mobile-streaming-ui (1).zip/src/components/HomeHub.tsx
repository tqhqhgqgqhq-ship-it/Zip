import { motion } from "framer-motion";
import Hero from "./Hero";
import CommunityUploads from "./CommunityUploads";
import Categories from "./Categories";
import MovieRow from "./MovieRow";
import { BrainIcon, SearchIcon } from "../icons";
import type { User } from "../auth";

export default function HomeHub({ 
  user, 
  onSearch 
}: { 
  user: User; 
  onSearch: () => void 
}) {
  return (
    <motion.div 
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      transition={{ type: "spring", damping: 30, stiffness: 300 }}
      className="h-full overflow-y-auto no-scrollbar pb-32"
      id="scroll-host"
    >
      <header className="sticky top-0 z-[60] flex items-center justify-between px-5 py-4 backdrop-blur-xl bg-black/20">
        <div className="flex items-center gap-2">
          <div className="h-10 w-10 flex items-center justify-center rounded-2xl bg-gradient-to-br from-orange-400 to-orange-600 shadow-glow-orange shadow-orange-500/20">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" className="animate-pulse">
              <rect x="2" y="2" width="20" height="20" rx="2.18" />
              <path d="M7 2v20M17 2v20M2 12h20M2 7h5M2 17h5M17 17h5M17 7h5" />
            </svg>
          </div>
          <span className="font-display text-2xl tracking-[0.1em] text-white">REELIO</span>
        </div>

        <div className="flex-1 max-w-[140px] mx-4">
          <button 
            onClick={onSearch}
            className="w-full flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-3 py-2 transition-all hover:bg-white/10 active:scale-95"
          >
            <SearchIcon className="h-4 w-4 text-zinc-400" />
            <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Search</span>
          </button>
        </div>

        <div className="h-10 w-10 overflow-hidden rounded-full border-2 border-white/10 ring-4 ring-white/5 transition-transform hover:scale-105 active:scale-95 cursor-pointer">
          {user.avatar_url ? (
            <img src={user.avatar_url} alt="" className="h-full w-full object-cover" />
          ) : (
            <div className="h-full w-full bg-zinc-800 flex items-center justify-center text-xs font-black text-white">
              {user.display_name?.[0]?.toUpperCase() || "U"}
            </div>
          )}
        </div>
      </header>

      <Hero />
      
      <div className="px-5 mt-8">
        <button
          onClick={onSearch}
          className="group flex w-full items-center gap-3 rounded-[28px] border border-white/10 bg-white/[0.04] p-4 text-left shadow-2xl shadow-black/30 backdrop-blur-xl transition-all duration-300 hover:bg-white/[0.06] active:scale-[0.99]"
        >
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white text-black shadow-xl group-hover:scale-110 transition-transform">
            <BrainIcon className="h-5 w-5" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[10px] font-black uppercase tracking-[0.24em] text-zinc-500">Reelio Intelligence</span>
            <span className="mt-1 block truncate text-sm font-bold text-white">Find any movie in community cloud</span>
          </span>
          <SearchIcon className="h-5 w-5 shrink-0 text-zinc-400" />
        </button>
      </div>

      <div className="px-5 mt-10 mb-2">
        <h2 className="section-accent text-xl font-black tracking-tight text-white">Featured Community Cinema</h2>
      </div>
      <CommunityUploads />
      
      <Categories />
      
      <MovieRow title="Trending Communities" movies={[]} showUploads />
      <MovieRow title="Top Ranked" movies={[]} large ranked showUploads />
      <MovieRow title="Editor's Choice" movies={[]} showUploads />
      <MovieRow title="Hidden Gems" movies={[]} showUploads />

      <div className="px-5 pt-12 pb-16 text-center opacity-40">
        <p className="font-display text-xl tracking-[0.25em] text-zinc-500">REELIO STUDIO</p>
        <p className="mt-1 text-[10px] font-black uppercase tracking-[0.3em] text-zinc-600">The Ultimate Cinematic Operating System</p>
        <p className="mt-8 text-[8px] font-bold text-zinc-700 tracking-widest uppercase">Version 4.5.0 Premium</p>
      </div>
    </motion.div>
  );
}
