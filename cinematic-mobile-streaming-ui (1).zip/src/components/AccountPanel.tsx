import { useEffect, useMemo, useRef, useState } from "react";
import { XIcon, UserIcon, FilmIcon, StarIcon, PlayIcon, UploadIcon, CheckCircleIcon } from "../icons";
import type { User } from "../auth";
import { updateProfile } from "../auth";
import { useUploads } from "../hooks/useUploads";
import { fetchProfileFromTelegram, formatBytes, saveProfileToTelegram, uploadProfileImageToTelegram } from "../telegram";
import { fallbackPoster } from "../metadataBrain";
import { deleteMovieFromCloud } from "../cloudStorage";
import { removeMovieFromStore } from "../hooks/useUploads";

export default function AccountPanel({
  user,
  onUserUpdate,
  onClose,
  onLogout,
}: {
  user: User;
  onUserUpdate: (user: User) => void;
  onClose: () => void;
  onLogout: () => void;
}) {
  const uploads = useUploads();
  const fileRef = useRef<HTMLInputElement>(null);
  const [editOpen, setEditOpen] = useState(false);
  const [savingAvatar, setSavingAvatar] = useState(false);
  const [localUser, setLocalUser] = useState(user);
  const [draft, setDraft] = useState({
    display_name: user.display_name || "",
    username: user.username || "",
    title: user.title || "Creator",
    bio: user.bio || "Building a personal cinema library on Reelio.",
  });

  useEffect(() => {
    let cancelled = false;
    fetchProfileFromTelegram(user.id).then(async (profile) => {
      if (cancelled || !profile) return;
      const merged = await updateProfile(user, profile);
      setLocalUser(merged);
      setDraft({
        display_name: merged.display_name || "",
        username: merged.username || "",
        title: merged.title || "Creator",
        bio: merged.bio || "Building a personal cinema library on Reelio.",
      });
      onUserUpdate(merged);
    });
    return () => { cancelled = true; };
  }, [user.id]);

  const stats = useMemo(() => {
    const totalSize = uploads.reduce((sum, item) => sum + (item.fileSize || 0), 0);
    const views = uploads.reduce((sum, item) => sum + (item.watchCount || 0), 0);
    return { totalSize, views };
  }, [uploads]);

  const saveDraft = async () => {
    const profile = { ...draft, userId: localUser.id, avatar_file_id: localUser.avatar_file_id, avatar_url: localUser.avatar_url, updated_at: Date.now() };
    await saveProfileToTelegram(profile);
    const updated = await updateProfile(localUser, draft);
    setLocalUser(updated);
    onUserUpdate(updated);
    setEditOpen(false);
  };

  const handleAvatar = async (file?: File) => {
    if (!file) return;
    setSavingAvatar(true);
    try {
      const uploaded = await uploadProfileImageToTelegram(file);
      await saveProfileToTelegram({
        userId: localUser.id,
        display_name: localUser.display_name,
        username: localUser.username,
        title: localUser.title,
        bio: localUser.bio,
        avatar_file_id: uploaded.fileId,
        avatar_url: uploaded.url,
        updated_at: Date.now(),
      });
      const updated = await updateProfile(localUser, {
        avatar_file_id: uploaded.fileId,
        avatar_url: uploaded.url,
      });
      setLocalUser(updated);
      onUserUpdate(updated);
    } finally {
      setSavingAvatar(false);
    }
  };

  const handleDeleteMovie = async (movieId: string) => {
    if (!confirm("Are you sure you want to delete this movie?")) return;
    try {
      await deleteMovieFromCloud(movieId);
      removeMovieFromStore(movieId);
    } catch (err) {
      console.error("[Account] Delete failed:", err);
      alert("Delete failed. Please try again.");
    }
  };

  const handleClearLibrary = async () => {
    if (!confirm("DANGER: This will delete ALL movies in the community library. Are you sure?")) return;
    if (!confirm("LAST WARNING: This action cannot be undone.")) return;
    
    try {
      for (const movie of uploads) {
        await deleteMovieFromCloud(movie.id);
        removeMovieFromStore(movie.id);
      }
      alert("Library cleared.");
    } catch (err) {
      console.error("[Account] Clear failed:", err);
      alert("Failed to clear some movies.");
    }
  };

  return (
    <div className="absolute inset-0 z-50 overflow-hidden bg-[#070709] text-white animate-details-in">
      <div className="pointer-events-none absolute -top-24 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-orange-500/10 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 right-0 h-72 w-72 rounded-full bg-white/5 blur-3xl" />

      <div className="relative h-full overflow-y-auto no-scrollbar pb-28">
        <div className="sticky top-0 z-20 flex items-center justify-between border-b border-white/10 bg-black/45 px-5 py-4 backdrop-blur-2xl">
          <div>
            <p className="text-[10px] font-black uppercase tracking-[0.28em] text-zinc-500">Reelio Account</p>
            <h1 className="text-xl font-black tracking-tight">Profile</h1>
          </div>
          <button onClick={onClose} className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/5 active:scale-95">
            <XIcon className="h-5 w-5" />
          </button>
        </div>

        <div className="px-5 pt-6">
          <div className="relative overflow-hidden rounded-[34px] border border-white/10 bg-white/[0.045] p-5 shadow-2xl shadow-black/40 backdrop-blur-2xl">
            <div className="absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-orange-500/15 to-transparent" />
            <div className="relative flex items-center gap-4">
              <button onClick={() => fileRef.current?.click()} className="group relative h-20 w-20 shrink-0">
                <div className="relative flex h-20 w-20 items-center justify-center overflow-hidden rounded-[28px] bg-gradient-to-br from-orange-300 to-orange-700 text-3xl font-black shadow-[0_18px_50px_rgba(255,122,24,0.28)]">
                  {localUser.avatar_url ? <img src={localUser.avatar_url} alt="avatar" className="h-full w-full object-cover" /> : (localUser.display_name?.[0]?.toUpperCase() || localUser.email[0]?.toUpperCase() || "U")}
                  <div className="absolute inset-0 flex items-end justify-center bg-gradient-to-t from-black/70 to-transparent p-2 opacity-0 transition group-hover:opacity-100">
                    <UploadIcon className="h-4 w-4 text-white" />
                  </div>
                </div>
                {savingAvatar && <div className="absolute inset-0 rounded-[28px] border-2 border-white/50 animate-pulse" />}
                <div className="absolute -right-1 -top-1 flex h-7 w-7 items-center justify-center rounded-full border border-white/20 bg-emerald-400 text-black shadow-lg">
                  <StarIcon className="h-3.5 w-3.5" />
                </div>
              </button>
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => handleAvatar(e.target.files?.[0])} />

              <div className="min-w-0 flex-1">
                <h2 className="truncate text-2xl font-black leading-tight">{localUser.display_name || "Creator"}</h2>
                <p className="mt-1 truncate text-sm text-zinc-400">@{localUser.username || localUser.email.split("@")[0]}</p>
                <p className="mt-1 truncate text-xs font-bold text-orange-200/80">{localUser.title || "Reelio Creator"}</p>
                <div className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-[10px] font-black uppercase tracking-wider text-emerald-300">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-300" /> Verified Creator
                </div>
              </div>
            </div>
            <p className="relative mt-4 text-sm leading-relaxed text-zinc-300">{localUser.bio || draft.bio}</p>
            <button onClick={() => setEditOpen(true)} className="relative mt-4 w-full rounded-2xl border border-white/10 bg-white/8 py-3 text-sm font-black text-white backdrop-blur-xl active:scale-[0.98]">
              Edit Profile
            </button>
          </div>

          <div className="mt-5 grid grid-cols-3 gap-3">
            <Stat icon={<FilmIcon className="h-4 w-4" />} label="Uploads" value={String(uploads.length)} />
            <Stat icon={<PlayIcon className="h-4 w-4" />} label="Views" value={String(stats.views)} />
            <Stat icon={<UserIcon className="h-4 w-4" />} label="Storage" value={formatBytes(stats.totalSize)} />
          </div>

          <Section title="Watch History">
            {uploads.slice(0, 4).map((item) => <MovieMini key={item.id} item={item} onDelete={handleDeleteMovie} />)}
            {uploads.length === 0 && <p className="text-sm text-zinc-500">No watch history yet.</p>}
          </Section>

          <Section title="Saved Movies / Watchlist">
            {uploads.slice(0, 3).map((item) => <MovieMini key={item.id} item={item} onDelete={handleDeleteMovie} />)}
            {uploads.length === 0 && <p className="text-sm text-zinc-500">Your watchlist is empty.</p>}
          </Section>

          <Section title="Manage Uploads">
            <p className="text-[10px] text-zinc-500 mb-2">Delete movies permanently from Reelio cloud.</p>
            {uploads.length === 0 ? (
              <p className="text-xs text-zinc-600">No movies found.</p>
            ) : (
              <div className="space-y-2">
                {uploads.map((m) => (
                  <div key={m.id} className="flex items-center justify-between rounded-xl bg-white/[0.03] p-2 border border-white/5">
                    <div className="flex items-center gap-2 min-w-0">
                      <img src={m.poster || fallbackPoster(m.title, m.genres, m.year)} className="h-10 w-7 rounded object-cover" />
                      <div className="min-w-0">
                        <p className="text-[11px] font-bold text-white truncate">{m.title}</p>
                        <p className="text-[9px] text-zinc-500">{m.year}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDeleteMovie(m.id)}
                      className="ml-2 flex h-8 w-8 items-center justify-center rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 active:scale-90 transition-all"
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                        <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                      </svg>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </Section>

          <Section title="Settings">
            <InfoRow label="Cloud database" value="Firebase connected" />
            <InfoRow label="Media backend" value="Telegram storage" />
            <InfoRow label="Telegram files" value={`${uploads.length} files`} />
            <InfoRow label="Joined" value={new Date(localUser.created_at).toLocaleDateString()} />
            
            <button 
              onClick={handleClearLibrary}
              className="mt-4 w-full rounded-xl border border-red-500/20 bg-red-500/5 py-2.5 text-[10px] font-bold uppercase tracking-wider text-red-400 hover:bg-red-500/10 active:scale-95 transition-all"
            >
              Clear Community Library
            </button>
          </Section>

          <button onClick={onLogout} className="mt-6 w-full rounded-2xl border border-red-400/20 bg-red-500/10 py-3.5 text-sm font-black text-red-200 active:scale-[0.98]">
            Log out
          </button>
        </div>
      </div>

      {editOpen && (
        <div className="absolute inset-0 z-50 flex items-end bg-black/60 backdrop-blur-md" onClick={() => setEditOpen(false)}>
          <div className="w-full rounded-t-[34px] border border-white/10 bg-[#0a0a0c] p-5 shadow-2xl animate-slide-up" onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto mb-4 h-1 w-12 rounded-full bg-white/20" />
            <h3 className="text-xl font-black">Edit Profile</h3>
            <div className="mt-5 space-y-3">
              <Input label="Name" value={draft.display_name} onChange={(v) => setDraft({ ...draft, display_name: v })} />
              <Input label="Username" value={draft.username} onChange={(v) => setDraft({ ...draft, username: v.replace(/[^a-zA-Z0-9_]/g, "") })} />
              <Input label="Title" value={draft.title} onChange={(v) => setDraft({ ...draft, title: v })} />
              <label className="block">
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500">Bio / About</span>
                <textarea value={draft.bio} onChange={(e) => setDraft({ ...draft, bio: e.target.value })} rows={4} className="mt-2 w-full resize-none rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 text-sm text-white outline-none" />
              </label>
            </div>
            <button onClick={saveDraft} className="btn-3d-play mt-5 w-full rounded-2xl py-3.5 text-sm font-black">
              Save Profile
            </button>
          </div>
        </div>
      )}

    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-6 rounded-[28px] border border-white/10 bg-white/[0.04] p-4 backdrop-blur-xl">
      <h3 className="text-sm font-black">{title}</h3>
      <div className="mt-3 space-y-3">{children}</div>
    </div>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.045] p-3 backdrop-blur-xl">
      <div className="text-zinc-400">{icon}</div>
      <p className="mt-2 truncate text-base font-black">{value}</p>
      <p className="mt-0.5 text-[10px] font-bold uppercase tracking-wider text-zinc-500">{label}</p>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 text-xs">
      <span className="text-zinc-500">{label}</span>
      <span className="font-bold text-zinc-200">{value}</span>
    </div>
  );
}

function Input({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return (
    <label className="block">
      <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500">{label}</span>
      <input value={value} onChange={(e) => onChange(e.target.value)} className="mt-2 w-full rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 text-sm font-semibold text-white outline-none" />
    </label>
  );
}

function MovieMini({ item, onDelete }: { 
  item: { id: string; poster: string; title: string; year: string; fileSize: number; genres: string[] };
  onDelete?: (id: string) => void;
}) {
  return (
    <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/25 p-2.5">
      <img src={item.poster || fallbackPoster(item.title, item.genres, item.year)} alt="" className="h-14 w-10 rounded-lg object-cover bg-zinc-900" />
      <div className="min-w-0 flex-1">
        <p className="truncate text-xs font-bold">{item.title}</p>
        <p className="text-[10px] text-zinc-500">{item.year} · {formatBytes(item.fileSize)}</p>
      </div>
      {onDelete ? (
        <button 
          onClick={() => onDelete(item.id)}
          className="flex h-8 w-8 items-center justify-center rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-all"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
          </svg>
        </button>
      ) : (
        <CheckCircleIcon className="h-4 w-4 text-emerald-300" />
      )}
    </div>
  );
}