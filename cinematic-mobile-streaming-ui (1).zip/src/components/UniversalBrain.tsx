import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { PlayIcon, SearchIcon, XIcon, StarIcon } from "../icons";
import { useUploads } from "../hooks/useUploads";
import { useMovieContext } from "../movieContext";
import { fallbackPoster } from "../metadataBrain";
import type { MovieEntry } from "../telegram";

function normalize(value = "") {
  return value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, " ").trim();
}

function MovieResult({ movie, onPlay }: { movie: MovieEntry; onPlay: (movie: MovieEntry) => void }) {
  const poster = movie.poster || fallbackPoster(movie.title, movie.genres, movie.year);
  return (
    <motion.button 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
      onClick={() => onPlay(movie)} 
      className="group flex w-full gap-4 rounded-[28px] border border-white/10 bg-white/[0.03] p-4 text-left shadow-xl backdrop-blur-xl transition-all duration-300 hover:border-white/20 hover:bg-white/[0.06]"
    >
      <div className="relative h-40 w-28 shrink-0 overflow-hidden rounded-2xl bg-zinc-900 shadow-2xl">
        <img src={poster} alt={movie.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" onError={(e) => { (e.target as HTMLImageElement).src = fallbackPoster(movie.title, movie.genres, movie.year); }} />
        <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-black/90 to-transparent" />
        <div className="absolute left-2.5 top-2.5 rounded-full bg-emerald-500/20 px-2 py-0.5 text-[8px] font-black text-emerald-300 backdrop-blur-md border border-emerald-500/30">COMMUNITY</div>
      </div>
      <div className="min-w-0 flex-1 flex flex-col justify-center">
        <div className="flex items-start justify-between gap-2">
          <h3 className="truncate text-lg font-black leading-tight text-white">{movie.title}</h3>
          <span className="flex items-center gap-1 shrink-0 rounded-full bg-white/10 px-2 py-0.5 text-[10px] font-bold text-white">
            <StarIcon className="h-2.5 w-2.5 text-amber-300" />
            {movie.rating || "8.5"}
          </span>
        </div>
        <p className="mt-1.5 text-[11px] font-bold uppercase tracking-wider text-zinc-500">{movie.year || "2024"} · {movie.type.toUpperCase()}</p>
        <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-zinc-400 font-medium">{movie.overview || "Uploaded to Reelio cloud library."}</p>
        <div className="mt-4 flex items-center gap-2">
          <div className="flex h-9 items-center gap-1.5 rounded-full bg-white px-4 py-1 text-[11px] font-black text-black shadow-lg transition-transform group-hover:scale-105 active:scale-95">
            <PlayIcon className="h-4 w-4" /> 
            <span>PLAY NOW</span>
          </div>
          <div className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white backdrop-blur">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 5v14M5 12h14" /></svg>
          </div>
        </div>
      </div>
    </motion.button>
  );
}

export default function UniversalBrain({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [query, setQuery] = useState("");
  const uploads = useUploads();
  const movieCtx = useMovieContext();

  const results = useMemo(() => {
    const q = normalize(query);
    if (!q) return uploads.filter(m => !m.isReel).slice(0, 10);
    return uploads.filter((movie) => !movie.isReel && normalize([movie.title, movie.year, movie.type, ...(movie.genres || []), movie.overview].join(" ")).includes(q));
  }, [query, uploads]);

  function playMovie(movie: MovieEntry) {
    movieCtx.openMovie({ id: movie.id, title: movie.title, poster: movie.poster || fallbackPoster(movie.title, movie.genres, movie.year), backdrop: movie.poster || fallbackPoster(movie.title, movie.genres, movie.year), year: movie.year, rating: movie.rating || "Reelio", genres: movie.genres, overview: movie.overview, isUpload: true, entry: movie });
    onClose();
  }

  if (!open) return null;

  return (
    <div className="h-full flex flex-col bg-[#08080a] relative overflow-hidden">
      {/* Background blobs */}
      <div className="pointer-events-none absolute -top-40 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-orange-500/5 blur-[100px]" />
      
      <div className="p-6 pt-12 relative z-10">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-black tracking-tight text-white">Search</h2>
            <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.3em] mt-1">Community Database</p>
          </div>
          <button 
            onClick={onClose} 
            className="h-12 w-12 flex items-center justify-center rounded-full glass-morphism active:scale-90 transition-transform"
          >
            <XIcon className="h-6 w-6 text-white/70" />
          </button>
        </div>

        <div className="relative group">
          <div className="absolute -inset-1.5 bg-gradient-to-r from-orange-500/20 to-violet-500/20 rounded-[30px] blur opacity-0 group-focus-within:opacity-100 transition-opacity duration-500" />
          <div className="relative flex items-center gap-4 bg-white/[0.04] border border-white/10 rounded-[24px] px-6 py-4 backdrop-blur-2xl transition-all group-focus-within:border-white/20 group-focus-within:bg-white/[0.07] shadow-2xl">
            <SearchIcon className="h-6 w-6 text-zinc-500 group-focus-within:text-white transition-colors" />
            <input 
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Titles, actors, or genres..."
              className="flex-1 bg-transparent text-base font-bold text-white outline-none placeholder:text-zinc-700"
              autoFocus
            />
          </div>
        </div>

        <div className="mt-8 flex gap-2.5 overflow-x-auto no-scrollbar pb-2">
          {["All Content", "Movies", "Sci-Fi", "Action", "Anime", "Trending"].map((chip) => (
            <button key={chip} className="shrink-0 px-5 py-2.5 rounded-full border border-white/10 bg-white/5 text-[11px] font-black uppercase tracking-wider text-zinc-400 hover:text-white hover:border-white/20 hover:bg-white/10 transition-all active:scale-95">
              {chip}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-32 no-scrollbar relative z-10">
        <AnimatePresence mode="popLayout">
          {results.length === 0 ? (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-24 text-center"
            >
              <div className="h-24 w-24 rounded-[40px] bg-white/[0.03] border border-white/5 flex items-center justify-center mb-8 shadow-2xl">
                <SearchIcon className="h-10 w-10 text-zinc-800" />
              </div>
              <h3 className="text-2xl font-black text-white tracking-tight">No results found</h3>
              <p className="mt-3 text-[15px] text-zinc-500 max-w-[260px] leading-relaxed">We couldn't find any community uploads matching <span className="text-white">"{query}"</span></p>
            </motion.div>
          ) : (
            <div className="grid gap-5">
              {results.map((movie) => (
                <MovieResult key={movie.id} movie={movie} onPlay={playMovie} />
              ))}
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
