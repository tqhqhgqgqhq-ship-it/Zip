import { useState } from "react";
import { categories } from "../data";
import { useReveal } from "../hooks";

export default function Categories() {
  const [active, setActive] = useState("Action");
  const { ref, inView } = useReveal<HTMLDivElement>(0.1);
  return (
    <div ref={ref} className={`mt-6 ${inView ? "in-view" : ""} reveal`}>
      <div className="no-scrollbar flex gap-2.5 overflow-x-auto px-5 pb-1">
        {categories.map((c) => {
          const on = c === active;
          return (
            <button
              key={c}
              onClick={() => setActive(c)}
              className={`relative shrink-0 rounded-full px-4 py-2 text-sm font-semibold transition-all duration-300 active:scale-90 ${
                on
                  ? "animate-spring text-black"
                  : "border border-white/10 bg-white/5 text-zinc-300 backdrop-blur-md hover:bg-white/10 hover:text-white"
              }`}
              style={
                on
                  ? {
                      background: "linear-gradient(180deg, #ffffff 0%, #e0e0e2 100%)",
                      boxShadow:
                        "inset 0 1px 0 rgba(255,255,255,1), inset 0 -2px 0 rgba(0,0,0,0.12), 0 8px 16px rgba(0,0,0,0.5), 0 2px 4px rgba(0,0,0,0.35)",
                    }
                  : undefined
              }
            >
              <span className="relative">{c}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
