import { useEffect, useState, useRef } from "react";
import { motion } from "framer-motion";
import { 
  PlayIcon, StarIcon, XIcon, SparkleIcon, 
  HeartIcon, ShareIcon 
} from "../icons";
import { fallbackPoster } from "../metadataBrain";
import type { OpenMovieData } from "../movieContext";
import { useUploads } from "../hooks/useUploads";
import { toggleLike, hasLiked, getComments, type Comment } from "../cloudStorage";
import { getSession } from "../auth";

const sampleCast = [
  { name: "Keanu Reeves", role: "Lead", c: "#ff7a18" },
  { name: "Donnie Yen", role: "Caine", c: "#22d3ee" },
  { name: "Bill Skarsgård", role: "Marquis", c: "#a78bfa" },
  { name: "Ian McShane", role: "Winston", c: "#34d399" },
];

export default function MovieDetails({
  movie, onClose, onPlay,
}: {
  movie: OpenMovieData;
  onClose: () => void;
  onPlay: () => void;
}) {
  const [liked, setLiked] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const uploads = useUploads();
  const session = getSession();

  const similar = uploads.filter((u) => u.id !== movie.entry?.id && !u.isReel).slice(0, 6);

  useEffect(() => {
    if (session && movie.entry) {
      hasLiked(session.id, movie.entry.id).then(setLiked);
      getComments(movie.entry.id).then(setComments);
    }
  }, [movie.entry, session]);

  const handleLike = async () => {
    if (!session || !movie.entry) return;
    const isNowLiked = await toggleLike(session.id, movie.entry.id);
    setLiked(isNowLiked);
  };

  const poster = movie.poster || fallbackPoster(movie.title, movie.genres, movie.year);
  const imgErr = (e: React.SyntheticEvent<HTMLImageElement>) => {
    (e.target as HTMLImageElement).src = fallbackPoster(movie.title, movie.genres, movie.year);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className={`fixed inset-0 z-[100] overflow-hidden bg-[#08080a]`}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 overflow-hidden">
        <img
          src={poster} alt="" className="h-full w-full object-cover opacity-30"
          style={{ filter: `blur(80px)` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#08080a]/80 to-[#08080a]" />
      </div>

      {/* Top bar */}
      <div className="absolute inset-x-0 top-0 z-30 flex items-center justify-between px-6 pt-12">
        <button onClick={onClose} className="h-12 w-12 flex items-center justify-center rounded-full bg-white/5 border border-white/10 backdrop-blur-xl active:scale-90 transition-transform">
          <XIcon className="h-6 w-6 text-white" />
        </button>
        <button className="h-12 w-12 flex items-center justify-center rounded-full bg-white/5 border border-white/10 backdrop-blur-xl active:scale-90">
          <ShareIcon className="h-5 w-5 text-white" />
        </button>
      </div>

      <div ref={scrollRef} className="no-scrollbar relative h-full overflow-y-auto pt-24 pb-32">
        <div className="flex flex-col items-center px-6">
          {/* Main Poster */}
          <div className="relative z-10">
            <div className="absolute -inset-10 bg-orange-500/10 blur-[80px] rounded-full" />
            <div className="relative h-[420px] w-[280px] rounded-[40px] overflow-hidden border border-white/15 shadow-[0_40px_100px_rgba(0,0,0,0.8)]">
              <img src={poster} alt={movie.title} className="h-full w-full object-cover" onError={imgErr} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            </div>
          </div>

          {/* Title & Info */}
          <div className="mt-10 text-center space-y-4">
            <h1 className="font-display text-5xl text-white tracking-tight">
              {movie.title}
            </h1>
            
            <div className="flex items-center justify-center gap-3">
              <span className="px-3 py-1 rounded-lg bg-white/5 border border-white/10 text-[10px] font-black text-zinc-400 uppercase tracking-widest">{movie.year}</span>
              <span className="flex items-center gap-1 px-3 py-1 rounded-lg bg-amber-400/10 border border-amber-400/20 text-[10px] font-black text-amber-400 uppercase tracking-widest">
                <StarIcon className="h-3 w-3 text-amber-300" /> {movie.rating}
              </span>
              <span className="px-3 py-1 rounded-lg bg-white/5 border border-white/10 text-[10px] font-black text-zinc-400 uppercase tracking-widest">HD</span>
            </div>

            <p className="max-w-xs text-sm text-zinc-400 leading-relaxed mx-auto">
              {movie.overview || "A breathtaking cinematic journey awaits you in this community masterpiece."}
            </p>
          </div>

          {/* Action Row */}
          <div className="mt-10 flex w-full gap-4 px-4">
            <button 
              onClick={onPlay}
              className="flex-1 h-16 rounded-[24px] bg-white text-black font-black flex items-center justify-center gap-3 shadow-[0_20px_40px_rgba(255,255,255,0.2)] active:scale-95 transition-transform"
            >
              <PlayIcon className="h-6 w-6" />
              PLAY NOW
            </button>
            <button 
              onClick={handleLike}
              className={`h-16 w-16 rounded-[24px] flex items-center justify-center border transition-all ${liked ? 'bg-rose-500 border-rose-400 text-white shadow-[0_10px_30px_rgba(244,63,94,0.4)]' : 'bg-white/5 border-white/10 text-white active:scale-90'}`}
            >
              <HeartIcon className="h-6 w-6" style={{ fill: liked ? "currentColor" : "none" }} />
            </button>
          </div>

          {/* Details Section */}
          <div className="mt-12 w-full space-y-8">
             <div className="space-y-4">
                <h3 className="text-xs font-black text-zinc-500 uppercase tracking-[0.3em] ml-2">Categories</h3>
                <div className="flex flex-wrap gap-2">
                  {movie.genres.map(g => (
                    <span key={g} className="px-5 py-2.5 rounded-full bg-white/5 border border-white/10 text-xs font-bold text-white backdrop-blur-xl">
                      {g}
                    </span>
                  ))}
                </div>
             </div>

             <div className="space-y-4">
                <h3 className="text-xs font-black text-zinc-500 uppercase tracking-[0.3em] ml-2">Featured Cast</h3>
                <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
                  {sampleCast.map(p => (
                    <div key={p.name} className="shrink-0 flex flex-col items-center gap-3">
                       <div className="h-16 w-16 rounded-full border-2 border-white/10 bg-zinc-800 flex items-center justify-center text-xl font-black text-zinc-500">
                          {p.name[0]}
                       </div>
                       <div className="text-center">
                          <p className="text-[10px] font-black text-white truncate w-16">{p.name}</p>
                          <p className="text-[8px] font-bold text-zinc-600 uppercase tracking-tighter">{p.role}</p>
                       </div>
                    </div>
                  ))}
                </div>
             </div>

             {similar.length > 0 && (
               <div className="space-y-4">
                  <div className="flex items-center gap-2 ml-2">
                    <SparkleIcon className="h-4 w-4 text-orange-400" />
                    <h3 className="text-xs font-black text-zinc-500 uppercase tracking-[0.3em]">AI Recommendations</h3>
                  </div>
                  <div className="flex gap-3 overflow-x-auto no-scrollbar pb-4">
                    {similar.map(m => (
                      <div key={m.id} className="h-44 w-32 shrink-0 rounded-2xl overflow-hidden border border-white/10 shadow-2xl relative group">
                        <img src={m.poster || fallbackPoster(m.title, m.genres, m.year)} className="h-full w-full object-cover transition-transform group-hover:scale-110" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent p-2.5 flex items-end">
                           <p className="text-[9px] font-black text-white truncate">{m.title}</p>
                        </div>
                      </div>
                    ))}
                  </div>
               </div>
             )}

             <div className="space-y-4">
                <h3 className="text-xs font-black text-zinc-500 uppercase tracking-[0.3em] ml-2">Reviews ({comments.length})</h3>
                {comments.length === 0 ? (
                  <p className="text-sm text-zinc-600 ml-2">No reviews yet.</p>
                ) : (
                  <div className="space-y-3 px-2">
                    {comments.slice(0, 3).map(c => (
                      <div key={c.id} className="bg-white/5 border border-white/5 rounded-3xl p-4">
                        <p className="text-xs font-black text-white">{c.userName}</p>
                        <p className="text-xs text-zinc-400 mt-1 leading-relaxed">{c.text}</p>
                      </div>
                    ))}
                  </div>
                )}
             </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
