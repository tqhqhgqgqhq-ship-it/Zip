import { useEffect, useRef, useState } from "react";

// ═══════════════════════════════════════════════════════════════
//  MORPHING PLAY / PAUSE BUTTON
//  Spring-physics path interpolation between play triangle and
//  pause bars. Bounce + light diffusion on interaction.
// ═══════════════════════════════════════════════════════════════

// Play triangle path (centered in 100x100 viewBox)
const PLAY = "M 34 26 L 34 74 L 76 50 Z";
// Pause path (two bars)
const PAUSE = "M 32 26 L 44 26 L 44 74 L 32 74 Z M 56 26 L 68 26 L 68 74 L 56 74 Z";

// We morph via opacity+scale crossfade of two paths with spring scale,
// since SVG path morphing between different point counts needs a lib.
// This gives a premium fluid feel without external deps.

export default function MorphPlayButton({
  playing,
  onToggle,
  size = 92,
}: {
  playing: boolean;
  onToggle: () => void;
  size?: number;
}) {
  const [scale, setScale] = useState(1);
  const [bursts, setBursts] = useState<number[]>([]);
  const burstId = useRef(0);
  const lastTouchToggle = useRef(0);
  const springRef = useRef<number>(0);
  const targetRef = useRef(1);
  const velRef = useRef(0);
  const curRef = useRef(1);

  // Spring animation for press scale
  const animate = () => {
    const stiffness = 0.18;
    const damping = 0.62;
    const force = (targetRef.current - curRef.current) * stiffness;
    velRef.current = (velRef.current + force) * damping;
    curRef.current += velRef.current;
    setScale(curRef.current);
    if (Math.abs(velRef.current) > 0.001 || Math.abs(targetRef.current - curRef.current) > 0.001) {
      springRef.current = requestAnimationFrame(animate);
    } else {
      curRef.current = targetRef.current;
      setScale(targetRef.current);
    }
  };

  const press = () => {
    targetRef.current = 0.82;
    cancelAnimationFrame(springRef.current);
    springRef.current = requestAnimationFrame(animate);
  };

  const release = () => {
    targetRef.current = 1;
    // Overshoot bounce
    velRef.current = 0.08;
    cancelAnimationFrame(springRef.current);
    springRef.current = requestAnimationFrame(animate);
  };

  const handleClick = () => {
    const id = burstId.current++;
    setBursts((b) => [...b, id]);
    setTimeout(() => setBursts((b) => b.filter((x) => x !== id)), 650);
    onToggle();
  };

  useEffect(() => () => cancelAnimationFrame(springRef.current), []);

  const isPlay = !playing; // show play triangle when paused

  return (
    <button
      type="button"
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        if (Date.now() - lastTouchToggle.current < 450) return;
        handleClick();
      }}
      onMouseDown={press}
      onMouseUp={release}
      onMouseLeave={release}
      onTouchStart={(e) => {
        e.stopPropagation();
        press();
      }}
      onTouchEnd={(e) => {
        e.preventDefault();
        e.stopPropagation();
        release();
        lastTouchToggle.current = Date.now();
        handleClick();
      }}
      onPointerDown={(e) => {
        e.stopPropagation();
        press();
      }}
      onPointerUp={(e) => {
        e.preventDefault();
        e.stopPropagation();
        release();
      }}
      className="lg-playbtn"
      style={{ width: size, height: size, transform: `scale(${scale})` }}
    >
      {/* Glow rings on tap */}
      {bursts.map((id) => (
        <span key={id} className="lg-glow-ring lg-ring-burst" />
      ))}

      <svg width={size * 0.55} height={size * 0.55} viewBox="0 0 100 100">
        {/* Play triangle */}
        <path
          className="lg-morph-path"
          d={PLAY}
          style={{
            opacity: isPlay ? 1 : 0,
            transform: `scale(${isPlay ? 1 : 0.4}) rotate(${isPlay ? 0 : -90}deg)`,
            transformOrigin: "50px 50px",
            transition: "opacity 0.32s cubic-bezier(0.34,1.56,0.64,1), transform 0.42s cubic-bezier(0.34,1.56,0.64,1)",
          }}
        />
        {/* Pause bars */}
        <path
          className="lg-morph-path"
          d={PAUSE}
          style={{
            opacity: isPlay ? 0 : 1,
            transform: `scale(${isPlay ? 0.4 : 1}) rotate(${isPlay ? 90 : 0}deg)`,
            transformOrigin: "50px 50px",
            transition: "opacity 0.32s cubic-bezier(0.34,1.56,0.64,1), transform 0.42s cubic-bezier(0.34,1.56,0.64,1)",
          }}
        />
      </svg>
    </button>
  );
}
