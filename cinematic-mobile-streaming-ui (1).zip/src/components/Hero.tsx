import { useEffect, useRef, useState, useMemo } from "react";
import { heroMovies } from "../data";
import { PlayIcon, InfoIcon } from "../icons";
import { fallbackPoster } from "../metadataBrain";
import { useMovieContext } from "../movieContext";
import { useUploads } from "../hooks/useUploads";
import type { MovieEntry } from "../telegram";
import type { Movie } from "../data";

export default function Hero() {
  const uploads = useUploads();
  const communityMovies = useMemo(() => uploads.filter(m => !m.isReel).slice(0, 5), [uploads]);
  const hasCommunity = communityMovies.length > 0;
  const displayMovies = hasCommunity ? communityMovies : heroMovies;

  const [active, setActive] = useState(0);
  const [drag, setDrag] = useState(0);
  const [phase, setPhase] = useState(0);
  const startX = useRef<number | null>(null);
  const dragging = useRef(false);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const n = displayMovies.length;

  const go = (dir: number) => {
    setActive((a) => (a + dir + n) % n);
    setPhase((p) => p + 1);
  };

  const resetTimer = () => {
    if (timer.current) clearInterval(timer.current);
    timer.current = setInterval(() => {
      setActive((a) => {
        const next = (a + 1) % n;
        setPhase((p) => p + 1);
        return next;
      });
    }, 5500);
  };

  useEffect(() => {
    resetTimer();
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, [n]);

  const onStart = (x: number) => {
    startX.current = x;
    dragging.current = true;
    if (timer.current) clearInterval(timer.current);
  };
  const onMove = (x: number) => {
    if (!dragging.current || startX.current === null) return;
    setDrag(x - startX.current);
  };
  const onEnd = () => {
    if (!dragging.current) return;
    dragging.current = false;
    if (drag < -55) go(1);
    else if (drag > 55) go(-1);
    setDrag(0);
    startX.current = null;
    resetTimer();
  };

  const cur = displayMovies[active];
  
  // Data extraction logic with type safety
  const isCommunity = "uploadedAt" in cur;
  const title = cur.title || "";
  const year = cur.year || "";
  const rating = cur.rating ? String(cur.rating) : "8.5";
  const genres = isCommunity ? (cur as MovieEntry).genres : [(cur as Movie).genre];
  const genresStr = genres.join(" · ");
  const duration = isCommunity ? "2h" : (cur as Movie).duration;
  const poster = cur.poster || fallbackPoster(title, genres, year);
  const ambientBg = isCommunity ? "#1a1a1a" : (cur as Movie).bg;
  const subtitle = !isCommunity ? (cur as Movie).subtitle : "";

  const ctx = useMovieContext();

  const openHero = () => {
    if (isCommunity) {
      const m = cur as MovieEntry;
      ctx.openMovie({
        id: m.id,
        title: title,
        poster,
        backdrop: poster,
        year,
        rating,
        genres,
        overview: m.overview || `A community uploaded cinematic experience.`,
        isUpload: true,
        entry: m,
      });
    } else {
      const m = cur as Movie;
      ctx.openMovie({
        id: `hero-${m.id}`,
        title,
        poster,
        backdrop: poster,
        year,
        rating,
        genres,
        duration,
        overview: `${title}${subtitle ? ` — ${subtitle}` : ""}. A cinematic masterpiece pushing the boundaries of visual storytelling.`,
        isUpload: false,
      });
    }
  };

  return (
    <div className="relative">
      <div
        className="relative h-[62vh] min-h-[420px] w-full touch-pan-y select-none overflow-hidden"
        style={{ background: ambientBg }}
        onTouchStart={(e) => onStart(e.touches[0].clientX)}
        onTouchMove={(e) => onMove(e.touches[0].clientX)}
        onTouchEnd={onEnd}
        onMouseDown={(e) => onStart(e.clientX)}
        onMouseMove={(e) => dragging.current && onMove(e.clientX)}
        onMouseUp={onEnd}
        onMouseLeave={onEnd}
      >
        <div
          className="pointer-events-none absolute inset-0 transition-colors duration-1000"
          style={{
            background: `radial-gradient(110% 80% at 50% 35%, ${ambientBg} 0%, #08080a 88%)`,
          }}
        />

        {displayMovies.map((m: any, i) => {
          let offset = i - active;
          if (offset > n / 2) offset -= n;
          if (offset < -n / 2) offset += n;
          const isActive = offset === 0;
          const dragPct = drag / window.innerWidth;
          const pos = offset + dragPct;
          const x = pos * 100;
          const opacity = Math.abs(pos) > 1.05 ? 0 : 1 - Math.abs(pos) * 0.35;
          const scale = isActive ? 1 - Math.min(Math.abs(dragPct) * 0.04, 0.04) : 1.04;
          
          const mTitle = m.title || "";
          const mGenres = "genres" in m ? m.genres : [m.genre];
          const mPoster = m.poster || fallbackPoster(mTitle, mGenres, m.year);

          return (
            <div
              key={m.id}
              className="absolute inset-0"
              style={{
                transform: `translateX(${x}%) scale(${scale})`,
                opacity,
                zIndex: isActive ? 10 : 5,
                transition: dragging.current
                  ? "none"
                  : "transform 0.85s cubic-bezier(0.22,1,0.36,1), opacity 0.6s ease",
              }}
            >
              <img
                src={mPoster}
                alt={mTitle}
                draggable={false}
                className="h-full w-full object-cover"
                style={{
                  objectPosition: "center top",
                  transform: isActive ? "scale(1.08)" : "scale(1)",
                  animation: isActive ? "kenBurns 14s ease-in-out infinite alternate" : "none",
                  transition: dragging.current ? "none" : "transform 0.85s ease",
                  filter: "brightness(0.98) contrast(1.04) saturate(1.08)",
                }}
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = fallbackPoster(mTitle, mGenres, m.year);
                }}
              />
            </div>
          );
        })}

        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-56 bg-gradient-to-t from-[#08080a] via-[#08080a]/70 to-transparent" />
        <div className="pointer-events-none absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-black/60 via-black/20 to-transparent" />

        <div className="absolute inset-x-0 top-3 z-20 flex justify-center gap-1.5">
          {displayMovies.map((m, i) => (
            <button
              key={m.id}
              onClick={() => {
                setActive(i);
                setPhase((p) => p + 1);
                resetTimer();
              }}
              className="pointer-events-auto h-1 rounded-full transition-all duration-500"
              style={{
                width: i === active ? 22 : 6,
                background: i === active ? "#ffffff" : "rgba(255,255,255,0.35)",
                boxShadow: i === active ? "0 0 8px rgba(255,255,255,0.6)" : "none",
              }}
            />
          ))}
        </div>

        <div className="pointer-events-none absolute bottom-3 left-4 z-20 flex items-center gap-2 text-[11px] font-medium text-white/85 drop-shadow-lg">
          <span className="rounded-md bg-black/45 px-2 py-1 backdrop-blur-md border border-white/10">
            ★ {rating}
          </span>
          <span className="rounded-md bg-black/45 px-2 py-1 backdrop-blur-md border border-white/10">
            {year}
          </span>
        </div>
      </div>

      <div className="relative -mt-8 z-10 px-6 pb-2">
        <div key={cur.id + "-" + phase} className="text-center">
          <h1 className="font-display text-[44px] leading-none animate-scale-in">
            <span
              className="bg-clip-text text-transparent"
              style={{
                backgroundImage: `linear-gradient(180deg, #ffffff 20%, #ffb07a)`,
                textShadow: "0 2px 20px rgba(255,140,50,0.4)",
                WebkitTextStroke: "0.5px rgba(255,200,150,0.2)",
              }}
            >
              {title}
            </span>
          </h1>
          {subtitle && (
            <p
              className="mt-1.5 font-display text-[15px] tracking-[0.45em] animate-fade-up"
              style={{
                color: "#ffcc99",
                textShadow: "0 0 14px rgba(255,180,100,0.5)",
                animationDelay: "120ms",
              }}
            >
              {subtitle}
            </p>
          )}
          <div
            className="mt-2 flex items-center justify-center gap-2 text-[11px] font-medium text-zinc-400 animate-fade-up"
            style={{ animationDelay: "240ms" }}
          >
            <span>{genresStr}</span>
            <span className="h-1 w-1 rounded-full bg-zinc-600" />
            <span>{duration}</span>
          </div>
        </div>

        <div className="mt-5 flex items-center justify-center gap-3">
          <button
            onClick={openHero}
            className="btn-3d-play flex flex-1 items-center justify-center gap-2 rounded-2xl py-3.5 text-[15px] font-bold"
          >
            <PlayIcon className="h-5 w-5" />
            Play
          </button>
          <button
            onClick={openHero}
            className="btn-3d-details flex flex-1 items-center justify-center gap-2 rounded-2xl py-3.5 text-[15px] font-semibold"
          >
            <InfoIcon className="h-5 w-5" />
            Details
          </button>
        </div>
      </div>
    </div>
  );
}
