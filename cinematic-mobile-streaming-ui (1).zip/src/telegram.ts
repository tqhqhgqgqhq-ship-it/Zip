// ═══════════════════════════════════════════════════════════════
//  REELIO STORAGE ENGINE — TELEGRAM ONLY
// ═══════════════════════════════════════════════════════════════
//  Video files and profile media are hosted on Telegram.
//  Metadata is stored in Turso Cloud.
// ═══════════════════════════════════════════════════════════════

const BOT_TOKEN = "8692277039:AAGpidQXTAC3VSquIyqyKPqXu7UDviQaoUE";
const CHANNEL_ID = "-1003754553492";
const API = `https://api.telegram.org/bot${BOT_TOKEN}`;
const FILE_API = `https://api.telegram.org/file/bot${BOT_TOKEN}`;

// 50MB limit for browser-based bot uploads to api.telegram.org
const CHUNK_SIZE = 45 * 1024 * 1024;

export interface TelegramChunk {
  fileId: string;
  fileUniqueId: string;
  messageId: number;
  index: number;
  size: number;
}

export interface MovieEntry {
  id: string;
  title: string;
  overview: string;
  poster: string;
  genres: string[];
  year: string;
  rating: number;
  type: "movie" | "tv" | "anime" | "documentary" | "short";
  isReel?: boolean;
  telegramFileId: string;
  telegramFileUniqueId: string;
  telegramMessageId: number;
  isChunked: boolean;
  chunks?: TelegramChunk[];
  fileSize: number;
  fileName: string;
  mimeType: string;
  duration?: number;
  uploadedAt: number;
  uploadedBy: string;
  watchCount: number;
  likes: number;
}

export interface UploadProgress {
  phase: "preparing" | "uploading" | "processing" | "done" | "error";
  percent: number;
  bytesUploaded: number;
  bytesTotal: number;
  message: string;
  chunkIndex?: number;
  totalChunks?: number;
}

export interface TelegramUploadResult {
  ok: boolean;
  fileId: string;
  fileUniqueId: string;
  messageId: number;
  fileSize: number;
  mimeType?: string;
  fileName?: string;
  duration?: number;
  isChunked: boolean;
  chunks?: TelegramChunk[];
}

// ─── Single chunk upload ───
async function uploadOneChunk(
  blob: Blob,
  fileName: string,
  caption: string,
  onProgress: (loaded: number) => void
): Promise<{ fileId: string; fileUniqueId: string; messageId: number; mimeType?: string; duration?: number }> {
  return new Promise((resolve, reject) => {
    const formData = new FormData();
    formData.append("chat_id", CHANNEL_ID);
    formData.append("document", blob, fileName);
    if (caption) formData.append("caption", caption.slice(0, 1024));
    formData.append("disable_notification", "true");

    const xhr = new XMLHttpRequest();
    xhr.open("POST", `${API}/sendDocument`);
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(e.loaded); };
    xhr.onload = () => {
      if (xhr.status === 413) return reject(new Error("File too large"));
      try {
        const data = JSON.parse(xhr.responseText);
        if (!data.ok) return reject(new Error(data.description || "Telegram API Error"));
        const doc = data.result.document || data.result.video || data.result.audio;
        resolve({
          fileId: doc.file_id,
          fileUniqueId: doc.file_unique_id,
          messageId: data.result.message_id,
          mimeType: doc.mime_type,
          duration: doc.duration,
        });
      } catch (err) { reject(new Error(`Server Error: ${xhr.status}`)); }
    };
    xhr.onerror = () => reject(new Error("Network Error: Check your connection to Telegram."));
    xhr.send(formData);
  });
}

export async function uploadVideoToTelegram(
  file: File,
  caption: string,
  onProgress: (p: UploadProgress) => void
): Promise<TelegramUploadResult> {
  onProgress({ phase: "preparing", percent: 0, bytesUploaded: 0, bytesTotal: file.size, message: "Preparing cloud storage..." });
  const numChunks = Math.max(1, Math.ceil(file.size / CHUNK_SIZE));
  const isChunked = numChunks > 1;
  const chunks: TelegramChunk[] = [];
  let totalUploaded = 0;
  let firstChunkInfo: any = null;

  for (let i = 0; i < numChunks; i++) {
    const start = i * CHUNK_SIZE;
    const end = Math.min(start + CHUNK_SIZE, file.size);
    const chunkBlob = file.slice(start, end);
    const chunkUploadedBefore = totalUploaded;
    onProgress({
      phase: "uploading",
      percent: Math.round((totalUploaded / file.size) * 94) + 2,
      bytesUploaded: totalUploaded,
      bytesTotal: file.size,
      message: isChunked ? `Optimizing data stream...` : `Uploading to Reelio Cloud...`,
      chunkIndex: i + 1,
      totalChunks: numChunks,
    });
    try {
      const result = await uploadOneChunk(chunkBlob, isChunked ? `${file.name}.part${i+1}` : file.name, i === 0 ? caption : "", (loaded) => {
        const currentTotal = chunkUploadedBefore + loaded;
        onProgress({
          phase: "uploading",
          percent: Math.min(Math.round((currentTotal / file.size) * 94) + 2, 95),
          bytesUploaded: currentTotal,
          bytesTotal: file.size,
          message: `${formatBytes(currentTotal)} / ${formatBytes(file.size)}`,
          chunkIndex: i + 1,
          totalChunks: numChunks,
        });
      });
      if (i === 0) firstChunkInfo = result;
      chunks.push({ fileId: result.fileId, fileUniqueId: result.fileUniqueId, messageId: result.messageId, index: i, size: chunkBlob.size });
      totalUploaded += chunkBlob.size;
    } catch (err: any) { throw new Error(err.message || "Upload Failed"); }
  }
  return { ok: true, fileId: firstChunkInfo.fileId, fileUniqueId: firstChunkInfo.fileUniqueId, messageId: firstChunkInfo.messageId, fileSize: file.size, mimeType: firstChunkInfo.mimeType || file.type, fileName: file.name, duration: firstChunkInfo.duration, isChunked, chunks: isChunked ? chunks : undefined };
}

// ─── Stream Resolution ───
async function resolveFileUrl(fileId: string): Promise<string> {
  const r = await fetch(`${API}/getFile?file_id=${encodeURIComponent(fileId)}`);
  const d = await r.json();
  if (!d.ok) throw new Error(d.description || "Link expired");
  return `${FILE_API}/${d.result.file_path}`;
}

export interface StreamProgress {
  phase: "fetching" | "ready";
  chunkIndex: number;
  totalChunks: number;
  bytesLoaded: number;
  bytesTotal: number;
}

export async function getStreamUrl(movie: MovieEntry, onProgress?: (p: StreamProgress) => void): Promise<string> {
  if (!movie.isChunked || !movie.chunks) return resolveFileUrl(movie.telegramFileId);
  const sorted = [...movie.chunks].sort((a, b) => a.index - b.index);
  const parts: Blob[] = [];
  let loaded = 0;
  for (let i = 0; i < sorted.length; i++) {
    onProgress?.({ phase: "fetching", chunkIndex: i + 1, totalChunks: sorted.length, bytesLoaded: loaded, bytesTotal: movie.fileSize });
    const url = await resolveFileUrl(sorted[i].fileId);
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`Part ${i+1} fail`);
    const b = await resp.blob();
    parts.push(b);
    loaded += b.size;
  }
  return URL.createObjectURL(new Blob(parts, { type: movie.mimeType || "video/mp4" }));
}

export async function getBlobStreamUrl(movie: MovieEntry): Promise<string> {
  const direct = await resolveFileUrl(movie.telegramFileId);
  const resp = await fetch(direct);
  if (!resp.ok) throw new Error("Blob fail");
  return URL.createObjectURL(await resp.blob());
}

// ─── Profiles ───
export async function uploadProfileImageToTelegram(file: File): Promise<{ fileId: string; url: string }> {
  const fd = new FormData();
  fd.append("chat_id", CHANNEL_ID);
  fd.append("photo", file, "avatar.jpg");
  const r = await fetch(`${API}/sendPhoto`, { method: "POST", body: fd }).then(x => x.json());
  if (!r.ok) throw new Error("Avatar fail");
  const best = r.result.photo[r.result.photo.length - 1];
  const url = await resolveFileUrl(best.file_id);
  return { fileId: best.file_id, url };
}

const PROFILE_MARKER = "##REELIO_PROFILE_V1##";
export async function saveProfileToTelegram(profile: any): Promise<void> {
  await fetch(`${API}/sendMessage`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chat_id: CHANNEL_ID, text: `${PROFILE_MARKER}\n${JSON.stringify(profile)}` }) });
}

export async function fetchProfileFromTelegram(userId: string): Promise<any | null> {
  try {
    const r = await fetch(`${API}/getUpdates?limit=100&timeout=0`).then(x => x.json());
    if (!r.ok) return null;
    let latest = null;
    for (const u of r.result) {
      const p = u.channel_post || u.message;
      const t = p?.text || "";
      if (!t.includes(PROFILE_MARKER)) continue;
      const data = JSON.parse(t.split("\n")[1]);
      if (data.userId === userId && (!latest || data.updated_at > latest.updated_at)) latest = data;
    }
    return latest;
  } catch { return null; }
}

export function createMovieEntry(upload: TelegramUploadResult, meta: any): MovieEntry {
  return { id: `reelio-${upload.fileUniqueId}-${Date.now()}`, title: meta.title, overview: meta.overview, poster: meta.poster, genres: meta.genres, year: meta.year, rating: 0, type: meta.type, telegramFileId: upload.fileId, telegramFileUniqueId: upload.fileUniqueId, telegramMessageId: upload.messageId, isChunked: upload.isChunked, chunks: upload.chunks, fileSize: upload.fileSize, fileName: upload.fileName || "movie.mp4", mimeType: upload.mimeType || "video/mp4", uploadedAt: Date.now(), uploadedBy: "Creator", watchCount: 0, likes: 0 };
}

export function formatBytes(b: number): string {
  if (b === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(b) / Math.log(k));
  return `${(b / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
}
