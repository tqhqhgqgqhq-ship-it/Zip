// ═══════════════════════════════════════════════════════════════
//  FIREBASE CLOUD MOVIE STORAGE
// ═══════════════════════════════════════════════════════════════

import { 
  collection, 
  doc, 
  setDoc, 
  getDocs, 
  deleteDoc, 
  updateDoc, 
  increment, 
  query, 
  orderBy,
  getDoc,
  where,
  addDoc,
  serverTimestamp
} from "firebase/firestore";
import { db } from "./firebase";
import { type MovieEntry } from "./telegram";

export async function saveMovieToCloud(movie: MovieEntry, userId: string): Promise<void> {
  console.log("[Firebase] Saving movie:", movie.title);
  
  const movieRef = doc(db, "movies", movie.id);
  await setDoc(movieRef, {
    ...movie,
    user_id: userId,
    updated_at: serverTimestamp()
  });
}

export async function loadAllMoviesFromCloud(): Promise<MovieEntry[]> {
  console.log("[Firebase] Loading all movies...");
  
  const q = query(collection(db, "movies"), orderBy("uploadedAt", "desc"));
  const querySnapshot = await getDocs(q);
  
  return querySnapshot.docs.map(doc => doc.data() as MovieEntry);
}

export async function deleteMovieFromCloud(movieId: string): Promise<void> {
  await deleteDoc(doc(db, "movies", movieId));
}

export async function incrementWatchInCloud(movieId: string): Promise<void> {
  const movieRef = doc(db, "movies", movieId);
  await updateDoc(movieRef, {
    watchCount: increment(1)
  });
}

// SOCIAL ACTIONS

export async function toggleLike(userId: string, movieId: string): Promise<boolean> {
  const likeId = `${userId}_${movieId}`;
  const likeRef = doc(db, "likes", likeId);
  const likeDoc = await getDoc(likeRef);
  const movieRef = doc(db, "movies", movieId);

  if (likeDoc.exists()) {
    await deleteDoc(likeRef);
    await updateDoc(movieRef, {
      likes: increment(-1)
    });
    return false;
  } else {
    await setDoc(likeRef, {
      user_id: userId,
      movie_id: movieId,
      created_at: Date.now()
    });
    await updateDoc(movieRef, {
      likes: increment(1)
    });
    return true;
  }
}

export async function hasLiked(userId: string, movieId: string): Promise<boolean> {
  const likeId = `${userId}_${movieId}`;
  const likeDoc = await getDoc(doc(db, "likes", likeId));
  return likeDoc.exists();
}

export interface Comment {
  id: string;
  userId: string;
  userName: string;
  avatarUrl?: string;
  text: string;
  createdAt: number;
}

export async function addComment(userId: string, movieId: string, text: string): Promise<void> {
  // Get user name for the comment
  const userDoc = await getDoc(doc(db, "users", userId));
  const userData = userDoc.data();
  
  await addDoc(collection(db, "comments"), {
    user_id: userId,
    movie_id: movieId,
    text,
    user_name: userData?.display_name || "Anonymous",
    avatar_url: userData?.avatar_url || "",
    created_at: Date.now()
  });
}

export async function getComments(movieId: string): Promise<Comment[]> {
  const q = query(
    collection(db, "comments"), 
    where("movie_id", "==", movieId),
    orderBy("created_at", "desc")
  );
  
  const querySnapshot = await getDocs(q);
  
  return querySnapshot.docs.map(doc => {
    const data = doc.data();
    return {
      id: doc.id,
      userId: data.user_id,
      userName: data.user_name,
      avatarUrl: data.avatar_url,
      text: data.text,
      createdAt: data.created_at,
    };
  });
}
