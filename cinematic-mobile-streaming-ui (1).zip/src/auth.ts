// ═══════════════════════════════════════════════════════════════
//  FIREBASE AUTHENTICATION SYSTEM
// ═══════════════════════════════════════════════════════════════

import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  updateProfile as firebaseUpdateProfile,
  onAuthStateChanged
} from "firebase/auth";
import { doc, getDoc, setDoc, updateDoc } from "firebase/firestore";
import { auth, db } from "./firebase";

export interface User {
  id: string;
  email: string;
  display_name?: string;
  username?: string;
  title?: string;
  bio?: string;
  avatar_file_id?: string;
  avatar_url?: string;
  banner_file_id?: string;
  banner_url?: string;
  created_at: number;
}

// Convert Firebase User + Firestore Data to Reelio User
async function mapUser(firebaseUser: any): Promise<User | null> {
  if (!firebaseUser) return null;

  console.log("[Auth] Mapping user data for:", firebaseUser.email);
  
  let userData: any = null;
  try {
    // Attempt to get Firestore data, but don't hang forever (5 second timeout)
    const userDocPromise = getDoc(doc(db, "users", firebaseUser.uid));
    const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout")), 5000));
    
    const userDoc: any = await Promise.race([userDocPromise, timeoutPromise]).catch(err => {
      console.warn("[Auth] Firestore profile fetch timed out or failed, using Auth defaults.", err);
      return null;
    });

    if (userDoc?.exists()) {
      userData = userDoc.data();
      console.log("[Auth] Firestore profile found.");
    }
  } catch (e) {
    console.error("[Auth] Firestore error during mapUser:", e);
  }

  return {
    id: firebaseUser.uid,
    email: firebaseUser.email || "",
    display_name: userData?.display_name || firebaseUser.displayName || firebaseUser.email?.split("@")[0] || "User",
    username: userData?.username || "",
    title: userData?.title || "Premium Member",
    bio: userData?.bio || "",
    avatar_file_id: userData?.avatar_file_id || "",
    avatar_url: userData?.avatar_url || firebaseUser.photoURL || "",
    banner_file_id: userData?.banner_file_id || "",
    banner_url: userData?.banner_url || "",
    created_at: userData?.created_at || Date.now(),
  };
}

export async function signup(email: string, password: string, displayName?: string): Promise<User> {
  console.log("[Auth] Starting signup for:", email);
  const credential = await createUserWithEmailAndPassword(auth, email, password);
  const firebaseUser = credential.user;
  console.log("[Auth] Firebase account created:", firebaseUser.uid);

  const reelioUser: User = {
    id: firebaseUser.uid,
    email: email.toLowerCase().trim(),
    display_name: displayName || email.split("@")[0],
    created_at: Date.now(),
  };

  // Create document in Firestore, but don't let it block the main flow if it fails/hangs
  try {
    console.log("[Auth] Saving Firestore profile...");
    setDoc(doc(db, "users", firebaseUser.uid), {
      display_name: reelioUser.display_name,
      email: reelioUser.email,
      created_at: reelioUser.created_at
    }).then(() => console.log("[Auth] Firestore profile saved."));
  } catch (e) {
    console.error("[Auth] Background Firestore save failed:", e);
  }

  if (displayName) {
    await firebaseUpdateProfile(firebaseUser, { displayName }).catch(() => null);
  }

  return reelioUser;
}

export async function login(email: string, password: string): Promise<{ user: User }> {
  const credential = await signInWithEmailAndPassword(auth, email, password);
  const user = await mapUser(credential.user);
  if (!user) throw new Error("Failed to map user data");
  return { user };
}

export function getSession(): User | null {
  const firebaseUser = auth.currentUser;
  if (!firebaseUser) return null;

  // This is a partial map because we can't do async getDoc here synchronously.
  // But for ID and Email it's enough.
  return {
    id: firebaseUser.uid,
    email: firebaseUser.email || "",
    display_name: firebaseUser.displayName || "",
    avatar_url: firebaseUser.photoURL || "",
    created_at: Date.now(), // approximation
  };
}

export async function logout(): Promise<void> {
  await signOut(auth);
}

export async function updateProfile(user: User, updates: Partial<User>): Promise<User> {
  const userRef = doc(db, "users", user.id);
  
  // Clean up updates for Firestore
  const filteredUpdates = { ...updates };
  delete (filteredUpdates as any).id;
  delete (filteredUpdates as any).email;

  await updateDoc(userRef, filteredUpdates);

  // If display name changed, update Firebase Auth profile too
  if (updates.display_name && auth.currentUser) {
    await firebaseUpdateProfile(auth.currentUser, { displayName: updates.display_name });
  }

  return { ...user, ...updates };
}

// Helper for App.tsx to listen for auth changes
export function subscribeToAuth(callback: (user: User | null) => void) {
  return onAuthStateChanged(auth, async (firebaseUser) => {
    if (firebaseUser) {
      const user = await mapUser(firebaseUser);
      callback(user);
    } else {
      callback(null);
    }
  });
}
