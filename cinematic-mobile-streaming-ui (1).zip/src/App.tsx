import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import HomeHub from "./components/HomeHub";
import BottomNav from "./components/BottomNav";
import UniversalBrain from "./components/UniversalBrain";
import UploadPortal from "./components/UploadPortal";
import MovieDetails from "./components/MovieDetails";
import CinematicPlayer from "./components/CinematicPlayer";
import AccountPanel from "./components/AccountPanel";
import ReelsFeed from "./components/ReelsFeed";
import AuthScreen from "./components/AuthScreen";
import { logout, type User, subscribeToAuth } from "./auth";
import { refreshMoviesFromCloud } from "./hooks/useUploads";
import { MovieContext, type OpenMovieData } from "./movieContext";

function StatusBar() {
  return (
    <div className="relative z-[70] flex items-center justify-between px-6 pt-3 text-white pointer-events-none">
      <span className="text-sm font-semibold tracking-wide drop-shadow-lg">9:41</span>
      <div className="flex items-center gap-1.5 drop-shadow-lg">
        <svg className="h-3.5 w-4" viewBox="0 0 24 24" fill="currentColor">
          <rect x="1" y="14" width="3.5" height="6" rx="1" />
          <rect x="7" y="10" width="3.5" height="10" rx="1" />
          <rect x="13" y="6" width="3.5" height="14" rx="1" />
          <rect x="19" y="2" width="3.5" height="18" rx="1" opacity="0.4" />
        </svg>
        <svg className="h-3.5 w-4" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 4C7.5 4 3.7 5.8 1 8.7l2 2C5.3 8.3 8.5 7 12 7s6.7 1.3 9 3.7l2-2C20.3 5.8 16.5 4 12 4Zm0 6c-2.5 0-4.8 1-6.5 2.7l2 2C8.7 13.6 10.3 13 12 13s3.3.6 4.5 1.7l2-2C16.8 11 14.5 10 12 10Zm0 5.5-2.5 2.5L12 20.5 14.5 18 12 15.5Z" />
        </svg>
        <div className="flex items-center">
          <div className="relative h-3.5 w-6 rounded-[3px] border border-white/60">
            <div className="absolute inset-[1.5px] right-1.5 rounded-[1px] bg-white" />
          </div>
          <div className="ml-px h-1.5 w-0.5 rounded-r bg-white/60" />
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"home" | "reels" | "search" | "profile">("home");
  
  // Modals / Overlays
  const [uploadOpen, setUploadOpen] = useState(false);
  const [detailsMovie, setDetailsMovie] = useState<OpenMovieData | null>(null);
  const [playerMovie, setPlayerMovie] = useState<OpenMovieData | null>(null);

  useEffect(() => {
    console.log("[App] Initializing Reelio Ecosystem...");
    const unsubscribe = subscribeToAuth((authenticatedUser) => {
      setUser(authenticatedUser);
      setLoading(false);
      if (authenticatedUser) {
        refreshMoviesFromCloud().catch(() => undefined);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleAuth = (authenticatedUser: User) => {
    setUser(authenticatedUser);
    refreshMoviesFromCloud().catch(() => undefined);
  };

  const handleLogout = async () => {
    await logout();
    setUser(null);
    setDetailsMovie(null);
    setPlayerMovie(null);
    setActiveTab("home");
  };

  const ctxValue = {
    openMovie: (data: OpenMovieData) => {
      setDetailsMovie(data);
      setPlayerMovie(null);
    },
  };

  if (loading) {
    return (
      <div className="flex min-h-screen w-full items-center justify-center bg-[#050507]">
        <div className="text-center animate-scale-in">
          <div className="relative mx-auto h-20 w-20 mb-8">
            <div className="absolute inset-0 animate-spin rounded-full border-[3px] border-white/5 border-t-orange-500" />
            <div className="absolute inset-0 flex items-center justify-center">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" className="animate-pulse opacity-60">
                <rect x="2" y="2" width="20" height="20" rx="2.18" />
                <path d="M7 2v20M17 2v20M2 12h20M2 7h5M2 17h5M17 17h5M17 7h5" />
              </svg>
            </div>
          </div>
          <p className="font-display text-2xl tracking-[0.25em] text-white">REELIO</p>
          <p className="mt-2 text-[10px] uppercase tracking-[0.4em] text-zinc-500 font-black">Next-Gen Cinema</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthScreen onAuth={handleAuth} />;
  }

  return (
    <MovieContext.Provider value={ctxValue}>
      <div className="flex min-h-screen w-full justify-center bg-[#050507]">
        <div className="relative w-full max-w-[440px] bg-[#08080a] shadow-[0_0_100px_rgba(0,0,0,1)] overflow-hidden">
          
          <StatusBar />

          <main className="h-screen overflow-hidden relative">
            <AnimatePresence mode="wait">
              {activeTab === "home" && (
                <HomeHub 
                  key="home"
                  user={user} 
                  onSearch={() => setActiveTab("search")} 
                />
              )}

              {activeTab === "reels" && (
                <motion.div 
                  key="reels"
                  initial={{ opacity: 0, scale: 1.1 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                  className="h-full bg-black"
                >
                  <ReelsFeed open={true} onClose={() => setActiveTab("home")} />
                </motion.div>
              )}

              {activeTab === "search" && (
                <motion.div 
                  key="search"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ type: "spring", damping: 30, stiffness: 300 }}
                  className="h-full bg-[#08080a]"
                >
                  <UniversalBrain open={true} onClose={() => setActiveTab("home")} />
                </motion.div>
              )}

              {activeTab === "profile" && (
                <motion.div 
                  key="profile"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ type: "spring", damping: 30, stiffness: 300 }}
                  className="h-full bg-[#08080a]"
                >
                  <AccountPanel
                    user={user}
                    onUserUpdate={setUser}
                    onClose={() => setActiveTab("home")}
                    onLogout={handleLogout}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </main>

          <BottomNav 
            activeTab={activeTab}
            onChangeTab={setActiveTab}
            onUpload={() => setUploadOpen(true)} 
          />

          <AnimatePresence>
            {uploadOpen && (
              <UploadPortal open={true} onClose={() => setUploadOpen(false)} user={user} />
            )}
          </AnimatePresence>

          <AnimatePresence>
            {detailsMovie && !playerMovie && (
              <MovieDetails
                movie={detailsMovie}
                onClose={() => setDetailsMovie(null)}
                onPlay={() => setPlayerMovie(detailsMovie)}
              />
            )}
          </AnimatePresence>

          <AnimatePresence>
            {playerMovie && (
              <CinematicPlayer
                movie={playerMovie}
                onClose={() => setPlayerMovie(null)}
              />
            )}
          </AnimatePresence>
        </div>
      </div>
    </MovieContext.Provider>
  );
}
