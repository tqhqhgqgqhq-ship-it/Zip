export function fallbackPoster(title: string, genres: string[] = [], year?: string) {
  const seed = `${title}-${year || ""}`;
  let hash = 0;
  for (let i = 0; i < seed.length; i += 1) hash = Math.imul(31, hash) + seed.charCodeAt(i);
  const hue = Math.abs(hash) % 360;
  const genre = genres[0] || "Cinema";
  const safeTitle = escapeXml(title || "Untitled").slice(0, 44);
  const safeGenre = escapeXml(genre).toUpperCase();
  const safeYear = year ? escapeXml(year) : "";
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="1200" viewBox="0 0 800 1200"><defs><radialGradient id="g" cx="50%" cy="18%" r="75%"><stop offset="0" stop-color="hsl(${hue},95%,48%)"/><stop offset=".42" stop-color="hsl(${(hue + 24) % 360},85%,18%)"/><stop offset="1" stop-color="#030305"/></radialGradient><linearGradient id="v" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".16"/><stop offset="1" stop-color="#000" stop-opacity=".68"/></linearGradient></defs><rect width="800" height="1200" fill="url(#g)"/><rect width="800" height="1200" fill="url(#v)"/><circle cx="640" cy="190" r="190" fill="#fff" opacity=".08"/><text x="70" y="850" font-family="Arial,sans-serif" font-size="72" font-weight="800" fill="#fff">${safeTitle}</text><text x="72" y="920" font-family="Arial,sans-serif" font-size="28" font-weight="700" fill="#ffffff99" letter-spacing="8">${safeGenre}</text>${safeYear ? `<text x="70" y="980" font-family="Arial,sans-serif" font-size="22" fill="#ffffff66">${safeYear}</text>` : ""}</svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

function escapeXml(value: string) {
  return value.replace(/[<>&'"]/g, (char) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;" }[char] || char));
}