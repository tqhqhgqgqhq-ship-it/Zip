import { createContext, useContext } from "react";
import type { MovieEntry } from "./telegram";

export interface OpenMovieData {
  id: string;
  title: string;
  poster: string;
  backdrop?: string;
  year: string;
  rating: string | number;
  genres: string[];
  duration?: string;
  overview?: string;
  isUpload: boolean;
  entry?: MovieEntry;
  demoVideoSrc?: string;
}

export interface MovieContextValue {
  openMovie: (data: OpenMovieData) => void;
}

// Default safe value — never throws
const noop = () => {};
export const MovieContext = createContext<MovieContextValue>({ openMovie: noop });

export function useMovieContext() {
  return useContext(MovieContext);
}
