// Reelio Discord Image compatible backend
// Deploy as a Cloudflare Worker, or adapt to any Worker-compatible runtime.
//
// Endpoints:
//   POST /api/reelio/admin/discord-config  { botToken, channelId }
//   GET  /api/reelio/admin/status
//   POST /upload                           multipart form field: image
//   GET  /file/:messageId                  redirects to latest Discord attachment URL
//
// Recommended production setup:
//   Bind a KV namespace named REELIO_CONFIG.
//   Secrets are stored backend-side only, never in Reelio frontend.

let memoryConfig = { botToken: "", channelId: "" };

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return cors(new Response(null, { status: 204 }));

    try {
      if (url.pathname === "/api/reelio/admin/status") {
        const cfg = await getConfig(env);
        return json({ ok: true, configured: Boolean(cfg.botToken && cfg.channelId) });
      }

      if (url.pathname === "/api/reelio/admin/discord-config" && request.method === "POST") {
        const body = await request.json();
        const botToken = String(body.botToken || "").trim();
        const channelId = String(body.channelId || "").trim();
        if (!botToken || !channelId) return json({ ok: false, error: "botToken and channelId are required" }, 400);

        await setConfig(env, { botToken, channelId });
        return json({
          ok: true,
          message: "Discord backend configured. Secrets are now backend-side.",
          publicUrl: url.origin,
          discordImageUrl: url.origin,
        });
      }

      if (url.pathname === "/upload" && request.method === "POST") {
        const cfg = await getConfig(env);
        if (!cfg.botToken || !cfg.channelId) return json({ ok: false, error: "Discord backend is not configured" }, 400);

        const form = await request.formData();
        const file = form.get("image") || form.get("file");
        if (!file || typeof file === "string") return json({ ok: false, error: "Missing file field image" }, 400);

        const discordForm = new FormData();
        discordForm.append("payload_json", JSON.stringify({ content: `Reelio upload: ${file.name || "movie"}` }));
        discordForm.append("files[0]", file, file.name || "movie.mp4");

        const discordResp = await fetch(`https://discord.com/api/v10/channels/${cfg.channelId}/messages`, {
          method: "POST",
          headers: { Authorization: `Bot ${cfg.botToken}` },
          body: discordForm,
        });
        const discordData = await discordResp.json();
        if (!discordResp.ok) return json({ ok: false, error: discordData.message || "Discord upload failed", details: discordData }, discordResp.status);

        const attachment = discordData.attachments?.[0];
        if (!attachment?.url) return json({ ok: false, error: "Discord returned no attachment URL" }, 502);

        return json({
          ok: true,
          url: `${url.origin}/file/${discordData.id}`,
          messageId: discordData.id,
          attachmentId: attachment.id,
          fileName: attachment.filename || file.name,
          mimeType: attachment.content_type || file.type || "video/mp4",
          fileSize: attachment.size || file.size,
        });
      }

      if (url.pathname.startsWith("/file/") && request.method === "GET") {
        const cfg = await getConfig(env);
        if (!cfg.botToken || !cfg.channelId) return json({ ok: false, error: "Discord backend is not configured" }, 400);

        const messageId = url.pathname.split("/").filter(Boolean)[1];
        const msgResp = await fetch(`https://discord.com/api/v10/channels/${cfg.channelId}/messages/${messageId}`, {
          headers: { Authorization: `Bot ${cfg.botToken}` },
        });
        const msg = await msgResp.json();
        if (!msgResp.ok) return json({ ok: false, error: msg.message || "Could not read Discord message" }, msgResp.status);
        const attachment = msg.attachments?.[0];
        if (!attachment?.url) return json({ ok: false, error: "No attachment found" }, 404);
        return Response.redirect(attachment.url, 302);
      }

      return json({ ok: true, service: "Reelio Discord Image Backend" });
    } catch (error) {
      return json({ ok: false, error: error?.message || "Unexpected backend error" }, 500);
    }
  },
};

async function getConfig(env) {
  if (env.REELIO_CONFIG) {
    const raw = await env.REELIO_CONFIG.get("discord");
    if (raw) return JSON.parse(raw);
  }
  return memoryConfig;
}

async function setConfig(env, config) {
  if (env.REELIO_CONFIG) {
    await env.REELIO_CONFIG.put("discord", JSON.stringify(config));
  }
  memoryConfig = config;
}

function json(body, status = 200) {
  return cors(new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  }));
}

function cors(response) {
  response.headers.set("Access-Control-Allow-Origin", "*");
  response.headers.set("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  response.headers.set("Access-Control-Allow-Headers", "Content-Type,Authorization");
  return response;
}
